-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 20 2014 г., 09:04
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `lessad`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `channels`
--

DROP TABLE IF EXISTS `channels`;
CREATE TABLE IF NOT EXISTS `channels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short` text COLLATE utf8_unicode_ci,
  `desc` text COLLATE utf8_unicode_ci,
  `file` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `channels`
--

INSERT INTO `channels` (`id`, `category_id`, `template`, `title`, `link`, `short`, `desc`, `file`, `image_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(4, 2, 'publication', 'Садовникова Т.П. Способ защиты древесины хвойных пород.', '', 'Авторское свидетельство № 1655360, 1088.', '', NULL, 0, 0, '2014-07-21 10:47:31', '2014-07-21 10:47:31'),
(5, 2, 'publication', 'Садовникова Т.П. Особенности применения аттрактантов короеда типографа в условиях Урала.', '', 'Ученые записки Тартуского Государственного Универститета 616, 1983, с.67–68.', '', NULL, 0, 0, '2014-07-21 10:48:57', '2014-07-21 10:48:57'),
(6, 2, 'publication', 'Садовникова Т.П., Кутеев Ф.С. Метод оперативного определения численности короеда типографа с помощью аттрактантов.', '', 'Журнал «Лесное зхозяйство» № 12, 1983, с. 51–52.', '', NULL, 0, 0, '2014-07-21 10:49:46', '2014-07-21 10:49:46'),
(7, 2, 'publication', 'Садовникова Т.П. Короед типограф и меры борьбы с ним.', '', 'Информационный бюллетень ВПРС МОББ, 41, Материалы докладов Международного симпозиума «Защита растений — проблемы и перспективы», Кишинев, 30–31 октября 2012, с.127–129.', '', NULL, 0, 0, '2014-07-21 10:51:07', '2014-07-21 10:51:07'),
(8, 1, 'documents', 'Открытое обращение в комитет лесного хозяйства Московской области', '', '0.9 МБ', '', '/uploads/1405942954_1146.pdf', 12, 0, '2014-07-21 11:39:36', '2014-07-21 11:42:34'),
(9, 1, 'documents', 'А.М. Жуков, Ю.И. Гниненко «Опасные малоизученные болезни хвойных пород в лесах России»', '', '10.5 МБ', '', '/uploads/1405947140_1773.pdf', 20, 0, '2014-07-21 12:52:20', '2014-07-21 12:58:10'),
(11, 1, 'documents', 'Я.Б. Мордкович «Насекомые в нашем доме»', '', '14.8 МБ', '', '/uploads/1405947611_1201.pdf', 22, 0, '2014-07-21 13:00:11', '2014-07-21 13:03:55'),
(12, 1, 'documents', 'А.Д. Маслов «Короед-типограф и усыхание еловых лесов»', '', '5.4 МБ', '', '/uploads/1405949074_1838.pdf', 23, 0, '2014-07-21 13:24:34', '2014-07-21 13:24:34');

-- --------------------------------------------------------

--
-- Структура таблицы `channel_category`
--

DROP TABLE IF EXISTS `channel_category`;
CREATE TABLE IF NOT EXISTS `channel_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `channel_category`
--

INSERT INTO `channel_category` (`id`, `title`, `slug`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Документы', 'docs', NULL, '2014-07-15 09:26:20', '2014-07-15 09:26:20'),
(2, 'Публикации', 'publication', NULL, '2014-07-15 09:26:27', '2014-07-15 09:26:27');

-- --------------------------------------------------------

--
-- Структура таблицы `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `published_at` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `events_publication_index` (`publication`),
  KEY `events_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `events_meta`
--

DROP TABLE IF EXISTS `events_meta`;
CREATE TABLE IF NOT EXISTS `events_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` mediumtext COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `events_meta_event_id_index` (`event_id`),
  KEY `events_meta_language_index` (`language`),
  KEY `events_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(2, 'user', 'Пользователи', '', '', '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(3, 'moderator', 'Модераторы', 'admin', '', '2014-07-07 14:32:27', '2014-07-07 14:32:27');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news`
--

DROP TABLE IF EXISTS `i18n_news`;
CREATE TABLE IF NOT EXISTS `i18n_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `i18n_news_publication_index` (`publication`),
  KEY `i18n_news_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news_meta`
--

DROP TABLE IF EXISTS `i18n_news_meta`;
CREATE TABLE IF NOT EXISTS `i18n_news_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_news_meta_news_id_index` (`news_id`),
  KEY `i18n_news_meta_language_index` (`language`),
  KEY `i18n_news_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages`
--

DROP TABLE IF EXISTS `i18n_pages`;
CREATE TABLE IF NOT EXISTS `i18n_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_publication_index` (`publication`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `i18n_pages`
--

INSERT INTO `i18n_pages` (`id`, `slug`, `template`, `publication`, `start_page`, `in_menu`, `sort_menu`, `created_at`, `updated_at`) VALUES
(1, '', 'index', 1, 1, 0, 87, '2014-07-09 11:36:55', '2014-08-18 10:23:22'),
(2, 'about', 'about', 1, 0, 0, 12, '2014-07-09 11:37:21', '2014-07-15 09:31:27'),
(3, 'catalog', 'catalog', 1, 0, 0, 9, '2014-07-09 11:37:34', '2014-07-15 09:29:22'),
(4, 'experience', 'default', 1, 0, 0, 77, '2014-07-09 11:37:49', '2014-07-29 13:09:12'),
(5, 'contacts', 'contacts', 1, 0, 0, 13, '2014-07-09 11:38:06', '2014-07-15 09:31:55'),
(7, 'search', 'search', 1, 0, 0, 15, '2014-07-15 12:57:13', '2014-07-15 13:04:34'),
(11, 'pervaya-massovaya-obrabotka-eli-v-podmoskove', 'default', 1, 0, 0, 79, '2014-07-22 09:21:39', '2014-07-29 13:13:04'),
(12, 'lechenie-vekovogo-duba-v-usadbe-griboedova', 'default', 1, 0, 0, 56, '2014-07-22 09:46:45', '2014-07-22 10:24:20'),
(13, 'obrabotka-kusta-ivy-sredstvom-savoiy-1', 'default', 1, 0, 0, 59, '2014-07-22 11:11:10', '2014-07-22 11:17:47'),
(14, 'likvidaciya-borshevika-sosnovskogo-sornyaka-opasnogo-dlya-lesnog', 'default', 1, 0, 0, 89, '2014-08-18 10:15:18', '2014-08-18 10:27:33');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages_meta`
--

DROP TABLE IF EXISTS `i18n_pages_meta`;
CREATE TABLE IF NOT EXISTS `i18n_pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_meta_page_id_index` (`page_id`),
  KEY `i18n_pages_meta_language_index` (`language`),
  KEY `i18n_pages_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `i18n_pages_meta`
--

INSERT INTO `i18n_pages_meta` (`id`, `page_id`, `language`, `name`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'Главная', '<div class="wrapper">\n	<div class="main-info">\n		<div>\n			<div class="info-circle" data-id="care">\n			</div>\n			<div class="info-circle" data-id="young">\n			</div>\n			<div class="info-circle" data-id="defend">\n			</div>\n			<div class="info-circle" data-id="rest">\n			</div>\n		</div>\n		<div>\n			<div class="info-block" data-id="young">\n				<div class="title">\n					          Омоложение\n				</div>\n				<div class="desc">\n					                                               Сад обычно сохраняет хорошее плодоношение до 30 лет. Защита деревьев от болезней и вредителей, от насекомых.\n				</div>\n			</div>\n			<div class="info-block" data-id="defend">\n				<div class="title">\n					          Защита\n				</div>\n				<div class="desc">\n					                                               Защита деревьев от болезней и вредителей, от насекомых.\n				</div>\n			</div>\n			<div class="info-block" data-id="care">\n				<div class="title">\n					          Лечение\n				</div>\n				<div class="desc">\n					                                               Различные методы борьбы с короедами. Защита деревьев от болезней и вредителей, от насекомых.\n				</div>\n			</div>\n			<div class="info-block" data-id="rest">\n				<div class="title">\n					          Реставрация\n				</div>\n				<div class="desc">\n					                                               Новые технологии лечения, с целью продления жизни деревьев.\n				</div>\n			</div>\n		</div>\n		<div class="slider-nav">\n			<a href="#" class="slider-dot"></a>\n			<!--                          -->\n			<a href="#" class="slider-dot"></a>\n			<!--                          -->\n			<a href="#" class="slider-dot"></a>\n			<!--                          -->\n			<a href="#" class="slider-dot"></a>\n		</div>\n	</div>\n</div>\n<div class="green-block">\n	<div class="wrapper">\n		                                   Производим средства для защиты<br>\n		                                   и лечения растений, деревьев<br>\n		                                   и кустарников. Обрабатываем, защищаем<br>\n		                                   и спасаем деревья с 1983 года.\n	</div>\n</div>\n<div class="info-slider">\n	<a href="#" class="slider-prev"></a><a href="#" class="slider-next"></a>\n	<div class="slider_fotorama" data-loop="true" data-width="100%" data-height="630px" data-nav="false" data-arrows="false">\n		<div class="slide" style="background-image: url(/theme/img/slide2.jpg)">\n			<div class="wrapper">\n				<div class="slide-text">\n					<div class="title">\n						          Борьба с борщевиком\n					</div>\n					<div class="desc">\n						     Ликвидация злостного сорняка – борщевика Сосновского. Это растение обладаюет способностью вызывать сильные и долго не заживающие ожоги. Истребить его очень трудно, распространяется он со страшной скоростью, захватывая всё новые территории. Наши специалисты успешно борятся с этим сорняком.\n					</div>\n					 <a href="/likvidaciya-borshevika-sosnovskogo-sornyaka-opasnogo-dlya-lesnog" class="us-btn">Подробнее</a> <br>\n				</div>\n			</div>\n		</div>\n		<div class="slide">\n			<div class="wrapper">\n				<div class="koroed">\n				</div>\n				<div class="slide-text">\n					<div class="title">\n						          Короед — причина гибели леса\n					</div>\n					<div class="desc">\n						     Время вспышки распространения короедов-типографов. Спасите лес от страшного вредителя!\n					</div>\n					 <a href="pervaya-massovaya-obrabotka-eli-v-podmoskove" class="us-btn">Подробнее</a> <br>\n				</div>\n			</div>\n		</div>\n	</div>\n</div>', 'glavnaya', 'Главная', '', '', '', '2014-07-09 11:36:55', '2014-08-18 10:23:22'),
(2, 2, 'ru', 'О компании', '<div class="about-top wrapper">\n	<div class="about-img-pen">\n	</div>\n	<div class="about-img-tree">\n	</div>\n	<div class="about-poem">\n		                           «Ах вы, рощи мои,дерева,<br>\n		                           Не рубили бы вас на дрова...»\n	</div>\n	<div class="us-text about-text">\n		                           Компания ЛессаД занимается производством средств для защиты                         и лечения садовых растений, кустарников и деревьев с 1983 года.                         При изготовлении средств мы используем составы с пониженным содержанием ядовитых веществ, чтобы не наносить вред окружающей среде. При этом эффективность лечения и стимулирование развития растений остаются на высоком уровне.\n	</div>\n	<div class="about-block">\n		<div class="title">\n			                               Лечение, реставрация<br>\n			  и омоложение деревьев\n		</div>\n		<ul class="about-list">\n			<li>Заделка (пломбирование) дупел старых деревьев                             </li>\n			<li>Заделка (пломбирование) дупел молодых, растущих  деревьев                             </li>\n			<li>Омолаживающее опиливание деревьев                             </li>\n			<li>Оздоровление приствольных кустов                         </li>\n		</ul>\n	</div>\n	<div class="about-block abs-block">\n		<div class="title">\n			  Защита от вредителей<br>\n			  с помощью прививок\n		</div>\n		<ul class="about-list">\n			<li>«Прививки» от насекомых-вредителей                             </li>\n			<li>Борьба с борщевиком                         </li>\n		</ul>\n	</div>\n</div>', 'o-kompanii', 'О компании', '', NULL, NULL, '2014-07-09 11:37:21', '2014-07-15 09:31:27'),
(3, 3, 'ru', 'Продукция', '', 'produkciya', 'Продукция', '', NULL, NULL, '2014-07-09 11:37:34', '2014-07-15 09:29:22'),
(4, 4, 'ru', 'Опыт', '<div class="about-posts">\n	<div class="wrapper">\n		<div class="about-img-stick">\n		</div>\n		<div class="parallax">\n			<div class="par-item">\n			</div>\n			<div class="par-item">\n			</div>\n		</div>\n		<div class="us-title mar-title">\n			       Многолетний опыт работы\n		</div>\n		<div class="posts-window">\n			<ul class="post-ul exp-ul">\n				<li>\n				<div class="post-photo" style="background-image: url(/uploads/HHzCZurF352n2F8q.jpg)">\n				</div>\n				 <a href="/lechenie-vekovogo-duba-v-usadbe-griboedova" class="title">Лечение векового дуба в усадьбе Грибоедова</a>\n				<div class="desc">\n					       В усадьбе Хмелита, музее-заповеднике А. С. Грибоедова, мы вылечили вековой дуб, на котором Александр Сергеевич качался еще в ребенком. Наши специалисты Садовникова Т.П. и Войтович В.А. провели мастер-класс по лечению и заделке дупла.<br>\n				</div>\n				 <a href="/lechenie-vekovogo-duba-v-usadbe-griboedova" class="post-link">Подробнее</a> </li>\n				<li>\n				<div class="post-photo" style="background-image: url(/uploads/avOpDVDtNm6PY993.jpg)">\n				</div>\n				 <a href="/pervaya-massovaya-obrabotka-eli-v-podmoskove" class="title">Первая массовая обработка ели в Подмосковье</a>\n				<div class="desc">\n					       Cовместно с Мособллесом мы провели первую массовую обработку ели в подмосковье.<br>\n				</div>\n				 <a href="/pervaya-massovaya-obrabotka-eli-v-podmoskove" class="post-link">Подробнее</a></li>\n				<li>\n				<div class="post-photo" style="background-image: url(/uploads/mEZEUPF6O4UsbQHg.jpg)">\n				</div>\n				 <a href="/obrabotka-kusta-ivy-sredstvom-savoiy-1" class="title">Обработка куста ивы средством «Савой-1»</a>\n				<div class="desc">\n					       Фотоотчет о спасении куста ивы от вредителей.<br>\n				</div>\n				 <a href="/obrabotka-kusta-ivy-sredstvom-savoiy-1" class="post-link">Подробнее</a></li>\n			</ul>\n		</div>\n	</div>\n</div>', 'opyt', 'Опыт', '', '', '', '2014-07-09 11:37:49', '2014-07-29 13:09:12'),
(5, 5, 'ru', 'Контакты', '<div class="wrapper">\n	<div class="us-block">\n		<div class="us-title">\n			  Контакты\n		</div>\n		<div id="map-block">\n		</div>\n		<div class="contact-block">\n			<div class="us-text contact-text">\n				                                   Для получения более подробной информации об используемых нами технологиях обращайтесь к нам по следующиму адресу:\n			</div>\n			<div class="contact">\n				<h2>Адрес:</h2>\n				<div class="us-text">\n					                                       Россия, 143900,<br>\n					                                       Московская область, г. Балашиха,<br>\n					                                       Щелковское шоссе, 54-Б<br>\n				</div>\n			</div>\n			<div class="contact">\n				<h2>Телефон:</h2>\n				<div class="us-text">\n					                                       +7 (495) 502-92-90<br>\n					                                       +7 (499) 479-69-20<br>\n				</div>\n			</div>\n			<div class="contact">\n				<h2>Email:</h2>\n				<div class="us-text">\n					                                       info@lessad.ru\n				</div>\n			</div>\n		</div>\n	</div>\n</div>', 'kontakty', 'Контакты', '', NULL, NULL, '2014-07-09 11:38:06', '2014-07-15 09:31:55'),
(7, 7, 'ru', 'Результаты поиска', '', 'rezultaty-poiska', 'Результаты поиска', '', NULL, NULL, '2014-07-15 12:57:13', '2014-07-15 13:04:34'),
(11, 11, 'ru', 'Первая массовая обработка ели в подмосковье (совместно с Мособллесом)', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			               Первая массовая обработка ели в подмосковье\n		</div>\n		        Cовместно с Мособллесом мы провели первую массовую обработку ели в <a href="http://maps.yandex.ru/?um=zoyI4aW8cYkal__Xfycwfk6inOgYHrXD&amp;ll=36.897184%2C55.922139&amp;spn=0.014377%2C0.005139&amp;z=17&amp;l=map" target="_blank">подмосковье</a>. <br>\n		<h2>Фотоотчет</h2>\n		 <span style="background-color: initial;">Обработка ели — стволовая прививка.</span> <br>\n		 <img src="/uploads/ClydF3urdXOgF4gj.jpg"> <br>\n		 <span style="background-color: initial;"></span><span style="background-color: initial;"><br>\n		Отдельно стоящий лесной массив у реки.</span> <br>\n		 <img src="/uploads/obKhS70WdnVmtu7s.jpg"> <br>\n		<br>\n		Погибшая ель, заселенная личинками черного елового усача. <br>\n		 <img src="/uploads/hiP9TF0XchRmII0T.jpg" style="opacity: 1;"> <br>\n		<br>\n		Погибшая ель с отверстиями заселения черного елового усача. <br>\n		 <img src="/uploads/mW83AZurWeZfOFMi.jpg"> <br>\n		<br>\n		Сухостой и зеленый сухостой ели. Деревья мертвы. <br>\n		 <img src="/uploads/JoMi4tuUMP4Id6Ah.jpg"> <br>\n		<br>\n		Участок, который будет защищаться. <br>\n		 <img src="/uploads/dJyrx1B3F7qjcX7m.jpg"> <br>\n		 <br>\n		<img src="/uploads/1Ch6WcllddZZ0N21.jpg"> <br>\n		<br>\n		Результат санитарной рубки. <br>\n		 <img src="/uploads/avOpDVDtNm6PY993.jpg"> <br>\n	</div>\n</div>', 'pervaya-massovaya-obrabotka-eli-v-podmoskove-sovmestno-s-mosobllesom', 'Первая массовая обработка ели в подмосковье (совместно с Мособллесом)', '', '', '', '2014-07-22 09:21:39', '2014-07-29 13:13:04'),
(12, 12, 'ru', 'Лечение векового дуба в усадьбе Грибоедова', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			<p>\n				  Лечение векового дуба в усадьбе Грибоедова\n			</p>\n		</div>\n		<p>\n			 <img src="/uploads/FY0bbgOUgefSA6DX.jpg" style="opacity: 1;">\n		</p>\n		<p>\n			  В усадьбе Хмелита, музее-заповеднике А. С. Грибоедова, мы вылечили вековой дуб, на котором Александр Сергеевич качался еще в ребенком. Наши специалисты <span style="background-color: initial;">Садовникова Т.П. и Войтович В.А. провели мастер-класс по лечению и заделке дупла.</span><span style="background-color: initial;"> </span>\n		</p>\n		<h2>Фотоотчет</h2>\n		<p>\n			 <img src="/uploads/IReCuo5ldoSW5pei.jpg">\n		</p>\n		<p>\n			 <img src="/uploads/VE39o3TekmHu4uF3.jpg" style="opacity: 1;">\n		</p>\n		<p>\n			<img src="/uploads/OMb8fr0a3UEkANXe.jpg" style="opacity: 1;">\n		</p>\n		<p>\n			<img src="/uploads/rfdwl3OFcu7MDUkI.jpg">\n		</p>\n		<p>\n			<img src="/uploads/9tdUoLTeZpj3RlEQ.jpg">\n		</p>\n		<p>\n			<img src="/uploads/xyeWGKfrtEBmkB00.jpg">\n		</p>\n		<p>\n			<img src="/uploads/HHzCZurF352n2F8q.jpg">\n		</p>\n		<p>\n			<img src="/uploads/8OT19KDTVS8Y7GlZ.jpg">\n		</p>\n		<p>\n			<img src="/uploads/ieTg8IpdI7OFkeIL.jpg">\n		</p>\n		<p>\n			<img src="/uploads/y0iQsUZP9xoIrceH.jpg">\n		</p>\n		<p>\n			<img src="/uploads/amBGJlJECtOeOpbi.jpg">\n		</p>\n		<p>\n			<img src="/uploads/nhctG6GpX1us3JpR.jpg">\n		</p>\n		<p>\n			<img src="/uploads/4OyeK5HIFPoRe4wM.jpg">\n		</p>\n	</div>\n</div>', 'lechenie-vekovogo-duba-v-usadbe-griboedova', 'Лечение векового дуба в усадьбе Грибоедова', '', NULL, NULL, '2014-07-22 09:46:45', '2014-07-22 10:24:20'),
(13, 13, 'ru', 'Обработка куста ивы средством «Савой-1»', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			  Обработка куста ивы средством «Савой-1»\n		</div>\n		<p>\n			<img src="/uploads/PXE3EEM257EjLwRz.jpg">\n		</p>\n		<p>\n			Ива в начале мая и такой оставалась до августа, и только в августе давала вторые листья. Всю летнюю жару были без тени! От этих насекомых:\n		</p>\n		<p>\n			<img src="/uploads/8rozRpbsEHlo6b4T.jpg">\n		</p>\n		<p>\n			<img src="/uploads/tpRYRTZb284cdKjl.jpg">\n		</p>\n		<h2>Лечение</h2>\n		<p>\n			Сделали уколы средством Савой по 1-1,5 мл под кору, и летом ива заколосилась новыми листьями. Уколы сделаны были поздно в июне, когда все ветки были уже обглоданы.\n		</p>\n		<p>\n			<span style="background-color: initial;">Новые листья подъедали насекомые, но при этом и гибли. На эти свежие листья слетались ещё насекомые с соседних деревьев, в результате и на соседних стало мало гусениц, тли и других.</span>\n		</p>\n		<p>\n			<img src="/uploads/RAVgxZZNVokOQGN6.jpg">\n		</p>\n		<p>\n			<span style="background-color: initial;"></span><span style="background-color: initial;">Привитая инъекциями «Савой-1» ива дала новые листочки. Фото сделано в августе. Полноценно распуститься ива не успела. Но ни одного насекомого на ней не было, хотя листья были подгрызены с краёв</span>.\n		</p>\n		<p>\n			На следующий год в апреле были сделаны инъекции средством «Савой-1» заблаговременно. Насекомые пытались съесть некоторые листочки. Результат отменный! Посмотрите общий результат на фото, она ранее никогда не пылила пухом, ее просто съедали!\n		</p>\n		<p>\n			<img src="/uploads/mEZEUPF6O4UsbQHg.jpg">\n		</p>\n		<p>\n			<img src="/uploads/EmATppMDa3Mhj6Ov.jpg">\n		</p>\n	</div>\n</div>', 'obrabotka-kusta-ivy-sredstvom-savoiy-1', 'Обработка куста ивы средством «Савой-1»', '', NULL, NULL, '2014-07-22 11:11:10', '2014-07-22 11:17:47'),
(14, 14, 'ru', 'Ликвидация борщевика Сосновского — сорняка, опасного для лесного хозяйства', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			      Ликвидация борщевика Сосновского — сорняка, опасного для лесного хозяйства <br>\n		</div>\n		      Садовникова Татьяна Петровна, <br>\n		    кандидат биологических наук, ООО «Лессад»                                   <br>\n		<br>\n		    Флора многих зон может изменяться после того, как происходит проникновение (инвазия) чужеродных видов растений из других ареалов. В некоторых случаях эти растения, называемые инвазионными, приобретают статус сорняка для естественного растительного сообщества, а некоторые  сорняки характеризуются уже как злостные, подавляющие рост растений в существовавшем биоценозе. Совершенно особый случай представляет завоз борщевика Сосновского, который входит в список злостных сорняков, подлежащих обязательному уничтожению.<br>\n		 <br>\n		    Проникновение борщевика на территорию нашей страны связано только с  деятельностью самого человека. В связи с большой урожайностью, богатым содержанием витаминов и легкостью произрастания в середине прошлого века борщевик был завезен с Кавказа в Нечерноземную и Черноземную зоны для решения вопроса кормопроизводства. Это растение достигает 4-х метровой высоты, что нашло отражение и в латинском наименовании его родапо аналогии с мифическим Гераклом – Heracleum sosnowskyi.<br>\n		 <br>\n		    Инвазия растений в зоны, отличающиеся по климатическим показателям и характеристикам почвы, приводит к приспособлению у части внедрившейся растительности к изменившимся условиям произрастания. Пластичность инвазионных объектов дает им возможность занять в течение определенного  времени соответствующее место в существовавшем травяном покрове. Роль новых объектов в этом случае и их влияние на сложившееся сообщество зависит от скорости их роста, развития и степени агрессивности. Такими отличительными признаками и обладает борщевик Сосновского, который  представляет угрозу лесному хозяйству.<br>\n		 <br>\n		    Однако с 1980 г.г. его перестали культивировать в связи с плохим потреблением силоса крупным рогатым скотом и появлением в мясе и молоке специфического запаха.<br>\n		 <br>\n		    В настоящее время одичавший борщевик стал агрессивным сорняком, распространяясь по обочинам шоссейных и железных дорог, осваивая пустующие территории, овраги и заброшенные площади земель. Борщевик разрастается на вырубках, опушках, в лесополосах, занимает свободные места в лесу, причем не только его окраины, но и внедряется под полог леса, часто подходит вплотную к деревьям, а иногда произрастает прямо в их приствольных кругах, забирая из почвы влагу и питательные вещества. <br>\n		 <br>\n		    Интенсивность размножения, с которой он осваивает территории, бросается в глаза  жителям многих районов нашей страны. В последнее время борщевик быстро распространился в Московской, Ленинградской, Вологодской, Калужской и Тульской области, а также в Чувашии,  Мордовии и в Пермском крае. Для успешного продвижения и произрастания борщевика решающим фактором является влагообеспеченность почвы, и поэтому он встречается в поймах рек и на орошаемых землях  засушливого Казахстана.<br>\n		 <br>\n		    Несмотря на очевидную активность борщевика и продолжающееся быстрое завоевание им различных площадей, определить ущерб от него пока трудно. Однако по нашим наблюдениям его произрастание уже доставляет определенные неудобства людям. Так, около берега Рыбинского водохранилищ (Тверская область), около запруды у реки Талица  (Московская область) заросли его препятствуют при вхождении в воду. Жители Подмосковья,прогуливающие собак, с их лапами заносят семена в свои палисадники. Перед юбилеем войны 1812 года в районе Бородинского поля пришлось уничтожать борщевик, растущий около мемориальных сооружений. <br>\n		 <br>\n		    Этот вид оказался особенно агрессивным за счет комплекса приспособлений к выживанию в широком спектре условий во все периоды своего роста. После окончания развития стебли его, ковром покрывающие почву, способствуют задержанию влаги, а благодаря быстрому разложению огромной биомассы обеспечивают прорастание новых всходов и возобновление уже более густого покрова в следующем году.<br>\n		 <br>\n		    Можно предположить, что даже одно растение борщевика, замеченное нами в районе монастыря около святого источника и его куртина, растущая на склоне берега реки Оки, послужат разрастанию этого сорняка и могут в довольно скором времени снизить запас воды в них.<br>\n		<br>\n		              Проведение мер по ликвидации борщевика оказалось затруднительным в связи с рядом биологических особенностей этого вида, благодаря которым он приспособился к интенсивному распространению и освоению новых территорий.<br>\n		 <br>\n		    К негативным свойствам борщевика относится такжеи содержание в его тканях особых веществ - фурокумаринов, в результате которых происходят фотохимические процессы на коже человека в солнечную погоду, вызывающие сильные, долго незаживающие ожоги. Необходимо помнить, что они не совсем аналогичны термическим ожогам, которые случаются в быту, так как характеризуются еще и проявлением сильной аллергии, трудно поддающейся лечению. <br>\n		 <br>\n		    В связи с отсутствием информации о негативных свойствах борщевика в сельской местности Пермского края наблюдали длительный процесс лечения ожогов у людей, которые, как выяснилось позднее, заготавливали ботву разросшегося борщевика около разрушенных ферм, где раньше его использовали для силосования и кормления скота. <br>\n		 <br>\n		    Кроме того, к особым биологическим особенностям борщевика относится то, что он подавляет всхожесть семян других видов растений за счет наличия особых эфирных масел в своих семенах. Эти масла высвобождаются после разложения оболочки семян и оказывают тормозящие действие на прорастание семян других видов растений.<br>\n		 <br>\n		    Характерным также для борщевика является растянутость процесса прорастания семян. В первый год может прорасти  только около половины всех семян, а остальные сохранят всхожесть до следующего года, хотя есть данные, что они остаются всхожими даже в течение нескольких лет. В период созревания семян для борщевика характерна поэтапная готовность семян в зонтиках, начинающаяся с центрального. Это следует рассматривать как  приспособление для гарантированного созревания хотя бы  части семян  при любых климатических условиях.<br>\n		 <br>\n		    Все перечисленные особенностиделают борщевик очень агрессивным, обеспечивая успешное его внедрение в различные угодья и освоение новых площадей, благодаря чему этот злостный сорняк продолжает широко распространяться  в нашей стране при отсутствии борьбы с ним. <br>\n		 <br>\n		    После проведения сплошной обработки гербицидами заросших борщевиком территорий  обработанные площади стоят бурые, покрытые погибшей растительностью, которая затем начинает восстанавливаться, причем возобновляется рост и борщевика. <br>\n		 <br>\n		     После кошения борщевика, которое часто применяется, добиться  хорошего результата тоже сложно. В срезанных стеблях борщевика скапливается дождевая вода, которая способствует росту боковых ответвлений от оставшихся в почве корней, причем это происходит при отсутствии процесса фотосинтеза в течение теплого периода года. Во время работы по ликвидации борщевика нами было установлено, что выкопанная корневая система к осени достигала веса свыше 2 кг, а от центрального корня  отходили на разных уровнях боковые ответвления до 1 м длиной. Из придаточных почек  этих ответвлений уже образуются не всходы, какие бывают из семян, а сразу растения, дающие розетки. Кроме того, после кошения на оставшейся части трубки часто успевает образоваться боковой побег, что позволяет даже при его длине всего в 10 см вырастить зонтик, хотя и несколько меньшего размера, но с полноценными семенами.<br>\n		 <br>\n		    Где целесообразно производить ежегодное кошение борщевика, так это по крутым склонам около дорог. В результате роста корней и их переплетения образуется плотное покрытие, предотвращающее смыв земли  дождевыми потоками. Если среди травы уже растет борщевик, то кошение позволяет не применять на склонах специального армирования почвы. <br>\n		 <br>\n		    Если борщевик не успевает дать зонтики с семенами, то рост корней в случае кошения у него не прекращается и уничтожение уже их требует специальных и более трудоемких обработок. Ликвидацию сорняка методически проводили в Европе владельцы усадеб, к территориям которых примыкали заросли борщевика. В нашей стране отсутствует информация об агрессивности сорняке, что приводит к тому, что осенью его везут для составления зимних букетов, рекламируют  его целебные свойства и для этого иногда его специально выращивают.<br>\n		 <br>\n		    Для успешной борьбы с борщевиком в лесном хозяйстве в первую очередь необходимо начать  просвещение населения о его вредоносности. Иногда в лесах рабочие сжигают порубочные остатки при рубке деревьев, не трогая куртину стоящего рядом сухого борщевика.<br>\n		 <br>\n		    Принимая во внимание эти данные, предлагается экологически безопасная технология, проверенная в умеренном и континентальном климате, которая основана на нарушении целостности тканей борщевика в разных фазах его развития с нанесением в эти места различных смесей веществ. Для их составления использовали рекомендуемые гербициды с сорбентами, а также с дополнительными веществами, способствующими быстрому продвижению гербицидов до корней.<br>\n		 <br>\n		    Там, где небезопасно применение гербицидов - приствольные круги деревьев, участки поблизости от садов и пасек - требуется обработка с использованием портативных приспособлений с безвредными препаратами, которые необходимо для этого разработать. Важно, чтобы лесник, выполняющий свою работу в лесу, при их наличии мог попутно ликвидировать встретившийся даже одиночный борщевик безопасным способом, как для себя, так и для всей экосистемы в целом. Необходимо помнить, что даже один борщевик может оставить после окончания своего развития столько семян, что на следующий год появиться уже целая куртина сорняка. <br>\n		 <br>\n		     Такую обработку целесообразнее проводить, когда уже начинают образовываться центральные стебли в виде трубки. Одни всходы бывают только в первый год внедрения борщевика, а впоследствии заросли его имеют разные стадии роста. При предлагаемом способе обработки не происходит загрязнения соседней площади, поскольку наблюдения покали, что она не затронула другие растения в непосредственной близости.<br>\n		 <br>\n		    Конечно, трудно осуществить ликвидацию борщевика повсеместно при произошедшем распространении его на нашей территории. Но целесообразно уже сейчас начать планомерную обработку его в местах произрастания саженцев лесных культур и в тех лесных массивах, где борщевик приносит ущерб растущим деревьям или нарушает декоративность ландшафта.<br>\n		<br>\n		    Работы этим методом могут  проводиться в каждой фазе  развития борщевика, начиная с его всходов, затем на ранних и поздних розетках с охватом точек роста, а также обрабатывая  образовавшиеся трубки в местах нарушения их целостности.<br>\n		 <br>\n		     После обработки площади следует проводить мониторинг, чтобы успеть предотвратить образование всходов из семян, сохраняющих свою всхожесть с прошлых лет. Необходимо помнить, что семена борщевика снабжены крылатками, облегчающими их распространение.<br>\n		 <br>\n		    В зависимости от целей использования площадей, которые были заросшими борщевиком, уничтожать его следует разными способами. Если после него предполагается проводить строительство, то следует провести сплошную обработку гербицидами. При зарослях борщевика вдоль дорог обработка должна проводиться выборочно, в зависимости  от близости к лесному массиву. В лесополосах и на вырубках, где планируются лесопосадочные работы, куртины должны ликвидироваться только предлагаемым способом обработки. <br>\n		 <br>\n		    Если же бывшие сельскохозяйственные  угодья  заросли борщевиком, то необходимо сочетать предлагаемую обработку с агротехническими мероприятиями. В этом случае, поскольку борщевик истощает почву на большой глубине, целесообразно с осени посеять озимую рожь, корни которой разрастаются  и в холодную погоду в противовес теплолюбивому борщевику. К весне рожь покрывает всю площадь, не позволяя образоваться новым всходам борщевика. При этом почва обогащается органическими веществами и по своим питательным свойствам полностью  реабилитируется. <br>\n		 <br>\n		    При проведении работ по уничтожению покрова борщевика на 2-х сотках в музее–усадьбе имени Ф.И. Тютчева  «Мураново» (Московская область) удалось предотвратить засорение их борщевиком и на следующий год.<br>\n		 <br>\n		 Всходы борщевика обрабатывали с помощью игольчатого валика, предварительно погруженного в Савой Б1. Обработку можно начинать в мае при образовании ранней розетки нанесением композиции <a href="http://www.conferum.ru/product/savoiy-b" target="_blank">Савой Б1</a> кистью в нежную точку роста. Такая же обработка проводится и на поздней розетке, но после нарушения целостности. После этого нужно дополнительно обработать композицией Савой Б2 появившиеся новые всходы борщевика по соседству.<br>\n		 <br>\n		 В случае состояния борщевика в фазе кущения следует после нарушения целостности верхушки растения наносить композицию Савой Б1, композицией Савой Б2 обрабатывается почва для предотвращения образования новых растений из спящих почек в корнях, а также запоздавших всходов.<br>\n		 <br>\n		 Обработки в период образования трубчатого стебля.Композицию Савой Б3 вносят в отверстие внутрь, через срез стебля, образованного после надрезания трубки острым инструментом перед началом проведения обработки, обработать почву вокруг оставшегося стебля композицией Савой Б4, обладающей гидроизоляционным эффектом для предотвращения вымывания химикатов дождями.<br>\n		    В качестве гербицида использовали «глифосад».<br>\n		 <br>\n		    Перед началом работ по предлагаемой технологии работники должны пройти инструктаж по технике безопасности  непосредственно на рабочем месте. Необходимо проследить обеспечение спецодеждой, питьевой водой и аптечкой первой помощи. При выполнении работ запрещается курить и принимать пищу. Зону проведения работ следует очертить оповещающим объявлением.<br>\n		 <br>\n		    Требующиеся для обработки борщевика инструменты, которые предотвращают образование ожогов у работников, а также комплект для удаления борщевика Сосновского для всех фаз развития на площадь 30-100 кв.м., можно приобрести в ООО «Лессад».<br>\n	</div>\n</div>', 'likvidaciya-borshevika-sosnovskogo-sornyaka-opasnogo-dlya-lesnogo-hozyaiystva', 'Ликвидация борщевика Сосновского — сорняка, опасного для лесного хозяйства', '', '', '', '2014-08-18 10:15:18', '2014-08-18 10:27:33');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_01_01_100000_create_groups_table', 1),
(2, '2014_01_01_100010_create_users_table', 1),
(3, '2014_01_01_100020_create_modules_table', 1),
(4, '2014_01_01_100030_create_actions_table', 1),
(5, '2014_01_01_100050_create_settings_table', 1),
(6, '2014_01_01_100051_create_storages_table', 1),
(7, '2014_01_01_100060_create_i18n_pages_table', 1),
(9, '2014_01_01_100080_create_galleries_table', 1),
(10, '2014_01_01_100090_create_photos_table', 1),
(11, '2014_01_01_100100_create_rel_mod_gallery_table', 1),
(12, '2014_01_01_100110_create_tags_table', 1),
(13, '2014_06_19_133757_create_production_tables', 1),
(16, '2014_07_14_124747_create_channels_tables', 3),
(17, '2014_01_01_100070_create_i18n_news_table', 4),
(18, '2014_07_07_135807_create_session_table', 4),
(19, '2014_07_08_145049_create_reviews_table', 4),
(20, '2014_07_23_150206_create_events_table', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'pages', 1, 0, '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(2, 'news', 0, 0, '2014-07-07 14:32:27', '2014-07-15 09:25:05'),
(3, 'galleries', 1, 0, '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(4, 'tags', 0, 0, '2014-07-07 14:32:27', '2014-07-15 09:25:09'),
(5, 'production', 1, 0, '2014-07-07 14:40:49', '2014-07-07 14:40:49'),
(6, 'reviews', 1, 0, '2014-07-09 11:39:34', '2014-07-09 11:39:34'),
(7, 'channels_menu', 1, 0, '2014-07-15 09:25:00', '2014-07-15 09:25:00');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, '1404905995_1017.jpg', '0', '2014-07-09 11:39:55', '2014-07-09 11:39:55'),
(11, '1405934576_1607.jpg', '0', '2014-07-21 09:22:56', '2014-07-21 09:22:56'),
(12, '1405942766_1483.jpg', '-1', '2014-07-21 11:39:27', '2014-07-21 11:39:36'),
(13, '1405943816_1680.png', '-1', '2014-07-21 11:56:56', '2014-07-21 11:56:58'),
(14, '1405943837_1431.png', '-1', '2014-07-21 11:57:17', '2014-07-21 11:57:19'),
(15, '1405943855_1720.png', '-1', '2014-07-21 11:57:35', '2014-07-21 11:57:36'),
(16, '1405943867_1453.png', '-1', '2014-07-21 11:57:47', '2014-07-21 11:57:49'),
(17, '1405943880_1479.png', '-1', '2014-07-21 11:58:00', '2014-07-21 11:58:02'),
(18, '1405944215_1802.jpg', '0', '2014-07-21 12:03:35', '2014-07-21 12:03:35'),
(19, '1405944746_1234.jpg', '0', '2014-07-21 12:12:26', '2014-07-21 12:12:26'),
(20, '1405947480_1661.jpg', '-1', '2014-07-21 12:58:00', '2014-07-21 12:58:10'),
(22, '1405947832_1632.jpg', '-1', '2014-07-21 13:03:52', '2014-07-21 13:03:55'),
(23, '1405949024_1033.jpg', '-1', '2014-07-21 13:23:44', '2014-07-21 13:24:34'),
(25, '1406277290_1143.jpg', '0', '2014-07-25 08:34:50', '2014-07-25 08:34:50'),
(26, '1408355519_1693.png', '0', '2014-08-18 09:51:59', '2014-08-18 09:51:59'),
(27, '1408355695_1655.png', '-1', '2014-08-18 09:54:55', '2014-08-18 09:54:57');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short` text COLLATE utf8_unicode_ci,
  `desc` text COLLATE utf8_unicode_ci,
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `category_id`, `title`, `link`, `short`, `desc`, `image_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Савой 1', 'http://www.conferum.ru/product/savoiy-1', '<p>\n	     Средство для защиты любых деревьев и кустарников. Применяется для борьбы с листогрызущими и сосущими насекомыми. Защищает от короеда-типографа, большого черного елового усача, стенографа и хермеса. Эффективен для лечения и реставрации деревьев.\n</p>\n<table class="product-table">\n<tbody>\n<tr>\n	<td>\n		               1 500 руб\n	</td>\n	<td>\n		               100 гр\n	</td>\n	<td>\n		               10–30 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		               3 750 руб\n	</td>\n	<td>\n		               250 гр\n	</td>\n	<td>\n		               25–65 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		               15 000 руб\n	</td>\n	<td>\n		            1 000 гр\n	</td>\n	<td>\n		               100–300 деревьев\n	</td>\n</tr>\n</tbody>\n</table>', '', 13, 0, '2014-07-16 08:23:07', '2014-08-18 10:04:05'),
(2, 1, 'Савой 2', 'http://www.conferum.ru/product/sredstva-dlya-zashity-derevev-savoiy-2', '<p>\n	   Средство для инъекционной обработки лесных и плодовых деревьев, а также защиты деревьев и кустарников. Применяется для инъекций от листогрызущих и сосущих насекомых, стволовых вредителей. Защищает от короеда-типографа, большого черного елового усача, стенографа и хермеса. Эффективен для лечения и реставрации деревьев.\n</p>\n<table class="product-table">\n<tbody>\n<tr>\n	<td>\n		          2 640 руб\n	</td>\n	<td>\n		            160 гр\n	</td>\n	<td>\n		            15–30 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		            7 040 руб\n	</td>\n	<td>\n		         480 гр\n	</td>\n	<td>\n		            40–130 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		         17 600 руб\n	</td>\n	<td>\n		            1 600 гр\n	</td>\n	<td>\n		            200 деревьев\n	</td>\n</tr>\n</tbody>\n</table>', '', 14, 0, '2014-07-21 08:54:43', '2014-08-18 10:04:03'),
(3, 1, 'Савой П-1', 'http://www.conferum.ru/product/savoiy-p1', '<p>\n	 Комплект подкормки на 10 деревьев с пролонгацией защиты от короедов и других насекомых на 1 год.\n</p>\n<p>\n	   Состав  сохраняет влагу для дерева, подпитывает удобрениями дерево и медленно  отдаёт Савой 1/2/3 дереву, который не даёт распространиться насекомым в  корнях, стволе и вегетативной части дерева.\n</p>', '', 15, 0, '2014-07-21 08:59:30', '2014-07-22 10:34:04'),
(4, 1, 'Савой Б', 'http://www.conferum.ru/product/savoiy-b', '<p>\n	 Комплект для удаления борщевика Сосновского на площади 30–100 м².\n</p>\n<p>\n	   Савой Б — это высокая эффективность технологии; низкий расход гербицида с точной дозировкой; безопасность рядом находящихся деревьев и других растений.\n</p>', '', 16, 0, '2014-07-21 09:04:12', '2014-07-22 10:33:44'),
(5, 1, 'Савой П-3', 'http://www.conferum.ru/product/savoiyp3', '<p>\n	 Комплект подкормки на 10 деревьев с удержанием влаги на 3 года.\n</p>\n<p>\n	   Состав сохраняет влагу для дерева, подпитывает удобрениями дерево и медленно отдаёт их дереву в течении 3 лет. Применяется для поддержания растений с засушливый период и после проведения инъекций в ствол.\n</p>', '', 17, 0, '2014-07-21 09:06:30', '2014-07-22 10:34:19'),
(6, 1, 'Савой 0', 'http://www.conferum.ru/product/savoiy-0', '<p>\n	 <span style="background-color: initial;">Транспортёр-смачиватель для ввода инсектицидов и пестицидов в растения. </span><span style="background-color: initial;">Применяется для ввода инсектицидов, гербицидов, пестицидов, фунгицидов, биоцидов в растения посредством снижения поверхностного натяжения, смачивания поверхности и усиленного проникновения в растения.</span>\n</p>', '', 27, 0, '2014-08-18 09:51:59', '2014-08-18 09:54:57');

-- --------------------------------------------------------

--
-- Структура таблицы `products_category`
--

DROP TABLE IF EXISTS `products_category`;
CREATE TABLE IF NOT EXISTS `products_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `products_category`
--

INSERT INTO `products_category` (`id`, `title`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Основная категория', NULL, '2014-07-16 08:22:22', '2014-07-16 08:22:22');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `published_at` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `reviews_publication_index` (`publication`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `template`, `slug`, `publication`, `image_id`, `gallery_id`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 'default', 'reviews-1', 1, 25, 0, '2014-07-09', '2014-07-25 08:34:52', '2014-07-25 08:34:52');

-- --------------------------------------------------------

--
-- Структура таблицы `reviews_meta`
--

DROP TABLE IF EXISTS `reviews_meta`;
CREATE TABLE IF NOT EXISTS `reviews_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `review_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` mediumtext COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `reviews_meta_review_id_index` (`review_id`),
  KEY `reviews_meta_language_index` (`language`),
  KEY `reviews_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `reviews_meta`
--

INSERT INTO `reviews_meta` (`id`, `review_id`, `language`, `name`, `position`, `preview`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'Грицай А.В.', 'ТСЖ «Зеленый городок», п. Андреевка', '<p>\n	Летом 2012 года я нашла Специалиста по борьбе с типографом — Садовникову Татьяну Петровну. Татьяна Петровна применила свою технологию по профилактике заражения типографом инсектицидом системного действия — препаратом «Савой» и оздоровления деревьев. Результат — лес на моем участке сохранен.\n</p>', '', 'gricaiy-av', 'Грицай А.В.', '', '', '', '2014-07-25 08:34:52', '2014-07-25 08:34:52');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('001cd06d14c893f5f6e9769a4fd73896e9bc0304', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicGZNTU9vQnF5ZVlZQnJab2dob29OZkZXRkc3dFVDeU85a1IzUDVCYiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NzY0MjU7czoxOiJjIjtpOjE0MDg0NzY0MjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408476426),
('010b035c727e02a0fbd5ca9ed83cf5e3c89ab1f1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlliQlNRcHhhU1FJVDVaejBtbHF5V09GTzQ1SnNlSnl5ZkRpYW0xSCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDkzNjY7czoxOiJjIjtpOjE0MDg1MDkzNjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408509366),
('026de528ae63ca4500ecf396f9cfbe5efb84c2b6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiak5teTlId0o5QVdvc1BUMFFpU3BUZ040NmxjODQxUE1WZm90dG56ciI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODg5MjE7czoxOiJjIjtpOjE0MDg0ODg5MjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408488922),
('037981df0fb8a7fd52dcc5abc432b864ac38f1cf', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibGVRRUVxSU9JU3M4SFdiVzRzQU9WeksySXhhanJTcVR5SWU5OTV6eCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjA3ODc7czoxOiJjIjtpOjE0MDg0MjA3ODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408420787),
('0408f36b16be392a34aa3536ade64eb47d9b8049', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidDJtSHpwMDJ6UXNkQ3BwMmhaZXBCVVpMdEFtSEVzaXplYkRQc1FzWCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjE4ODc7czoxOiJjIjtpOjE0MDg1MjE4ODc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408521887),
('041501ffbe770c3b5b9d1dbb8bf7fb8dbba2b811', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibVFJS3ZjdFYxVFZJNGNwUU41WWhKN3JWWTM3U01mb3VBWEVnZ1dORyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzU0MjA7czoxOiJjIjtpOjE0MDg0MzU0MjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408435420),
('041c2c967a698f30841b7962cb4757620312b396', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYzBSZVJzdzhzM0pjNzN2RkZiWUJBUXJlWVlvVHNJVmZkQXQ3S0ZCOSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzOTk5OTE7czoxOiJjIjtpOjE0MDgzOTk5OTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408399991),
('04b90b616db3c32f2f6ebae116671fe0bf2da6b8', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTGhmVXNvcXdUMHZLclVmUE1JNE1zSEJydnU2UW9jZ1hkWGxLTU8zbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDMwNDY7czoxOiJjIjtpOjE0MDg0MDMwNDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403046),
('0d3ae2361cb5552d6058dce3d4366bd0b41c41f0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiejBPcGxFTXcxS0pmNktjUmcwRGQzOFJySDV3dEdDRjdlbTZUbWdiMyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjUzMjc7czoxOiJjIjtpOjE0MDg0NjUzMjc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408465327),
('0e2043e845e6daa31a2628eae571cd227cdbae36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNnc5U1VQZmpOc3hrNktqNVVPY29Ia3dLaTgxaGx3SWRGcnRyS3pUSCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODQ0OTM4NDtzOjE6ImMiO2k6MTQwODQ0OTI4MDtzOjE6ImwiO3M6MToiMCI7fX0=', 1408449384),
('0eb597abe6c57c8f9a0eb11347a7fac5b3273efa', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibkx5RlFSVzlYcEhOODJEQkFINGdRMTQ5ZUdoWmVVYUMxWDdIczNCMiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDAxMTk7czoxOiJjIjtpOjE0MDg1MDAxMTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408500119),
('110da0acc33ac065faeb2f69ec0b550aad5df948', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVk53OFJ3cFRwZnFxS0xvNHUxNkU0UWwwNjc4ZnQxSGZXaG1wdXVpNiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTgzNTc7czoxOiJjIjtpOjE0MDg0NTgzNTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408458357),
('13f0225f2ce1651d7d2f8fffb7a7053e40a3a8f8', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidUpjd3FCdTQzNWNxS3dsZk9JRExGdFhyVDJCUDdlNUtuTEc3TUYxbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODc5NDg7czoxOiJjIjtpOjE0MDg0ODc5NDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408487948),
('14391299b7ed0a52e665309cbe31347d4557a318', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjBKdUxEQ2xYOTJPNEc5RTBTd1lqMGpzNDJ5ZVJUMFBaYTIyM0ZPUSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjAxNDk7czoxOiJjIjtpOjE0MDg0NjAxNDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408460149),
('1551f4c03a3a70c173badc611d827a8370f73104', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYkt3V0o1c0lQSFAwaGVUc01tOG1oTFU1dnV3MlYzelR3OHR2NzNSUyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTEyNDg7czoxOiJjIjtpOjE0MDg0NTEyNDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408451248),
('199569c2b4dd02d02d9f3e3d8cef000ec156bafd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ2VvTGFXSmxmS1lqUmJFYzBuUGV6cktXOXZxdEdlZlZ3c0ptdHhEOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTI2NzI7czoxOiJjIjtpOjE0MDg1MTI2NzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408512672),
('1aac2aec838518a59dec2918139da672292038a2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ2kzRnBHYk92VUFoTTN2UWZUbTFrN2RsQ0h3d0dWRTFwMFlhNWpLUiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDE3Nzk7czoxOiJjIjtpOjE0MDg0MDE3Nzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408401779),
('1ad37f9bb1b2a60aeedd36c3fae0f356aba67f9e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWlBINWxFdkdmZ1N0dmhXZXFLc3dMcWtqYXVHdzZVSWZHVkI2YWVCTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDMzOTY7czoxOiJjIjtpOjE0MDg0MDMzOTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403396),
('1d7dd2d1cd01081eea745c1c72bf0211921b28ac', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUEVtQ0VuYVpMbXowb2RSdVRjVklZTHlXZmVwUjhyREJ5Q2I4TDc1VSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjM0OTQ7czoxOiJjIjtpOjE0MDg1MjM0OTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408523494),
('1e9a0ea94b47fe1706ef35032a4978e90cd96d69', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOW5oQ2NjTVZJQzVoUUJKbHJNekEzblB6bUVud1hIUzd0WG1CNVhvRyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTI2NTc7czoxOiJjIjtpOjE0MDg1MTI2NTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408512657),
('205c8fa25670fa4f854e1d787c1a970d8dbee26a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZTh4Y2RHR2FTZmlVY1Jhdkx0OUdtZGNycGhwMm9yRlQ2MDZFck5iUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDU1MzA7czoxOiJjIjtpOjE0MDg0MDU1MzA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408405530),
('20836010c51127c8ef0291507475cb7f44552af1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVQ5T0dsVnN3Y2dQTXlCcGVNQUYzdFhUSDk2ODAxTll4ZFM1elI4YSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjY5NDc7czoxOiJjIjtpOjE0MDg0NjY5NDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408466947),
('21fb97b7fb5a44c832c000ab75f0847574b0d17e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmlEaEh1U2tjZXB1VnF4UU9uZnJaTGpLeTIyVXRzckpNNFlRQlBTNiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjM2NjM7czoxOiJjIjtpOjE0MDg1MjM2NjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408523663),
('2226e47f40e570a5aa6db91137e48ecf22be5ebf', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2hySHVCUndlcDVPUk5UYlM1bVYxZEJHTFp3ODNBUzJhRGJpbHpyRCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDQyODU7czoxOiJjIjtpOjE0MDg0MDQyODU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408404285),
('23abc48e790444cdc75db4bbe73746864fcdc820', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibDhoYVQ2a3NMU2dJUjVYR0N0ZDFGMkg3YXRpVjVvUmpEVXp2TERqbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTEzNDU7czoxOiJjIjtpOjE0MDg1MTEzNDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408511345),
('27c2fd7cc88cec00d53d25816694c3f171723dc5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTl1dGd0TWNTaW1Ebk04Q3RkSGsySUZvOVZ2Tlh5aUtwUHFFSEJZOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDQ1MjI7czoxOiJjIjtpOjE0MDg0NDQ1MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408444522),
('281188d2305ad76d876e3ba3b0ca642753c971ef', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVpMOXlHTnkxY2dUOGprVEVJYXJTOHlrTk1zSFlJYlA0cGFBRlRiRCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjEyNjg7czoxOiJjIjtpOjE0MDg1MjEyNjg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408521268),
('29d4aee11ee7ce6f1220e38182b13a2a7d3acefc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQld2ZkU3a1J4clhhWkRuMEVIc1lXa2lITjBUdmVyR1BHRmM0YTlaRyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDE0NTI7czoxOiJjIjtpOjE0MDg0MDE0NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408401452),
('2c10387f700e241f5d17729207d82f58fbefa847', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidkNxcFNNc2JHNnIyazBCcWNVSVJXRkZDd0VRUHVwcnFsd0g2WVdwNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTQ2NjI7czoxOiJjIjtpOjE0MDg0NTQ2NjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408454662),
('2c2644f8598b74d36c468f18429224d76c150d44', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2VUQXIwdGFvcnVWY3dnSnpEUm1HZjUyUkFQamdZajFSc251WHQxbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTM4MDE7czoxOiJjIjtpOjE0MDg1MTM4MDE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408513801),
('2c5cc73eeecf42aa43f8019bbc4d5d6a344648eb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSVhtWjNSRDNqV1luOFZHdEhQaTdFWW9EQUxFZjhqamVWOUJjTFFvVSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODUwMzQ7czoxOiJjIjtpOjE0MDg0ODUwMzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408485035),
('2d6b19f4453ca1437e03b1bb858dafe2045403fe', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieUFSU1dYbG14N2N3eTF1ckJBSjhoR0EwcDR3MFNpWXVQTmg4U0Q3eiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDMzMDY7czoxOiJjIjtpOjE0MDg0MDMzMDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403306),
('2f126823b1e7a640aa6a13ab7b104dd56f27d6dc', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWEFDYzBLd1VjQlRTNFI5Y3ZJaThtUkpPajY5QXI4cEcxUWJvQjdLUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTM5NDU7czoxOiJjIjtpOjE0MDg0NTM5NDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408453945),
('3164b3704d34ce9e3e3c227ba45d848d1fb60eb4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQklDMXFZTlRQMWxxcW9jSHV0aGJFUzU0bU11a09Jd2t4dDRaTVhvNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDgyNTA7czoxOiJjIjtpOjE0MDg0NDgyNTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408448250),
('31d251a59005d1e517cf12e4576b15066c69534e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMFVBVm9pSUNHMkVJdkF0TlFsbEh5UmVLYklHTVJCeG9nbVBDdG81ZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjExMjE7czoxOiJjIjtpOjE0MDg0MjExMjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408421121),
('32ade9a5e7b9f337db9fcb10bc24b5355ed9873b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYTRENjQzQ0tMekZ6REdNdGdscGFPdXRjb2Z2NGlZdGI2N1R1MnhwOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTYwNzc7czoxOiJjIjtpOjE0MDg1MTYwNzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408516077),
('353cace49763b02dec4fa4d84c82305aab536494', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZTRxOGxoYU02OERXejZVeHQ2VkU0aHh4SENwYzZSeUNJSDh0QVQyeCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODcxNDM7czoxOiJjIjtpOjE0MDg0ODcxNDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408487143),
('363fbb60c85e8f67612b97ce39922e1d117ebdcd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibnZQcHdRZDJmOWNudlFxYXVDU2huTXZLb2xCTkprVjZoSU5xUzM5ZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTI2Njc7czoxOiJjIjtpOjE0MDg1MTI2Njc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408512667),
('376c8c24067f85a8a9acdca3eb4ba615f4885980', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicU80WGk5QlhVckdJd3ozUkVSeGdGejlKdGp5R3Y0S2lEYkliZ3ZBbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTI2NjI7czoxOiJjIjtpOjE0MDg1MTI2NjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408512662),
('39c983d9e8bd93446cd98bf22965a7ac0be5f5fa', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic2o0dDBZZnpuRnJmY3IzNTFLT2VVUERhbkx6V1IybFZqTkZWZWlpUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjI1MjQ7czoxOiJjIjtpOjE0MDg1MjI1MjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408522525),
('3aa419ccf10e47b104003a340287e2dd32636dac', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNEJMZzJ4MkJNQkEwVVIxTkhFQzEwSGlHb1IzZkRiYlpTWDljVFhJYyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjY3ODQ7czoxOiJjIjtpOjE0MDg0MjY3ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408426784),
('3e711467a99fce6c6bfc91363eae3076b5780af2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTnhPMUZGWVFXY2E5a3JmVlBhYlVkSjk2U0hSclFtbDBwYnBmQk11TSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDk5NTg7czoxOiJjIjtpOjE0MDg0MDk5NTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408409958),
('40336202e1f4d1624deeac837ae3ca8af56d1755', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMUJJZXp5b01mZ255RkloSDdtTkVNVVpsRkhKNThNOEp1N2pZQ2hZdyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTUxOTU7czoxOiJjIjtpOjE0MDg0NTUxOTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408455195),
('40da6dd320bfbf43170b7f3e79e7d82596c1e544', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlA3U1VqQVl5QWEzMHdEaUtMakZKTG91ZWpDODZWVTZSZG5jRXg5VSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzI3MDA7czoxOiJjIjtpOjE0MDg0MzI3MDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408432700),
('41932a52ee0a62ea67fb00ee543cc2f61ee0e40e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoib2ZhSHp5R042THFTek1VRUZqcXlBTkg0VVg1cGpJWjhSQjFHY1d1ayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDk5Njc7czoxOiJjIjtpOjE0MDg0MDk5Njc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408409967),
('422b925f996fb4543f600974e87812d73bbb26e9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVB3Uk5KaXR5Q3hCTVhiZlFrdHk3TG9pblVJSGlaN01OS2xLQWdscCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTAwMjI7czoxOiJjIjtpOjE0MDg1MTAwMjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408510022),
('4421aa76bfaf09a15272fa53f6062a10fbf1297b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYXpRYzNPV25ZNndSSWdvSkQyMWxteHcwZllsbjVCZUVoaGd0Z3d0cSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzOTg3NTE7czoxOiJjIjtpOjE0MDgzOTg3NTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408398751),
('45ddca561aac42c5fd1d0a7ff56dbf79d4465860', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid0dkY3F4U01tQ0FtMHZkVThaQnppdWh5QU9Fa2hTdkYyYmFvT0JOUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDMzNzk7czoxOiJjIjtpOjE0MDg0NDMzNzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408443379),
('47802cdcbdfc016663dedf74367581de54aa193b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWXpWcVVjcVpTYW9kTWZjNW15UFc3N0VVTHZEeWZEZXZyTlgxRDhNbiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDA4NDQ7czoxOiJjIjtpOjE0MDg0MDA4NDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408400844),
('484ffe16e0416403865bb0b4e37f79a441011508', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTG00U0dWRXdYYlJxbDE5QktKaXRDMjdPUWVNVURTQWJjd1dONWxTRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTYwNzc7czoxOiJjIjtpOjE0MDg1MTYwNzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408516077),
('4969b3dfba3c748e67b2c87bd0aae62d54e4fe90', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUFdFUjBIZFg3U2NtYmFad1BqdEtNeHFzSXNqaHB6cndyTm9ZOWNRUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDEyMjc7czoxOiJjIjtpOjE0MDg0MDEyMjc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408401227),
('4a62d30d42cf5d093c263c564aa3d319c946e565', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzhlMU1wdzd1N2FuTXRuRXdIUnZFSU5sRzYwd20zTHI1TmVpcWxNTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDExNTA7czoxOiJjIjtpOjE0MDg0MDExNTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408401150),
('4b4ce99222709f9acbb0bbfa1abf333f54c47c0b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkJEMFlZaENZWklNRlNvMklEeXM1R2NzcW9Ma0hCdHNTVXFvS0JCYSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDIzNDU7czoxOiJjIjtpOjE0MDg0MDIzNDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408402345),
('4eec3b2f488899602a464e1f4e4749bf17a0d86c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ1luRXBydmN6ZHNZS0hidTVvMlQwclRaNHFpSFVRQUhRcmZSUHZLeSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDQ1MzM7czoxOiJjIjtpOjE0MDg0MDQ1MzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408404533),
('4f46269a27a4f9f4cf2b06620eecab0be863ce9e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ1JOS3ZrU1NOUXl3NUEyRGFTdDV1eHIwcUZUbFlEUTFtYjdsdDVHRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTkwNTM7czoxOiJjIjtpOjE0MDg0MTkwNTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408419053),
('4f94f5460b369c3cd6194dcad76f1ebf8bf15e3d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidTdoS3dYYmVoMXNnb3hSajVPTHVIb1pKaVdoSjZVeFZtRW1IWmJRaCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDM3NTk7czoxOiJjIjtpOjE0MDg0MDM3NTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403759),
('505f8b53461a91b6988e5ff3ef67cb4eb253d762', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiczlVYlJEWEVQQWRwN1gwbG53ZjVVeHN3dFN3elp1WlB0a3BFYk1vNCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTUwNzY7czoxOiJjIjtpOjE0MDg0NTUwNzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408455076),
('514d7b9fda58bd60a57fc6b8c48e5cc86cfb656f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMk9mSzhlTzJnWnpBSEdaN3ByWWEyQlVoeTRDa1lOVUVBeTFBRFl0ZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzgzNDk7czoxOiJjIjtpOjE0MDg0MzgzNDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408438349),
('525a3121e9b52dfe68acf8df7c321c8d6499da8a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZU1jdHF2a2xTRUExMDJEeUhaeGM5VmJ1eWhpemM5M0lxc3MxSmNtaCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Njk3MTY7czoxOiJjIjtpOjE0MDg0Njk3MTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408469716),
('569ee58e3c57c582e1ed6429e540eeddbc8b0afa', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSGVuNDhnZmloZXQ2OUthNTlrWXhNd3hmeGFDYmFrVk9RQnRTM2dERCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTUzMjE7czoxOiJjIjtpOjE0MDg0NTUzMjE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408455321),
('58cbe20f28a7e7720f257aa9d68df92d3f34c56e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1U1S2ZKdVZubzFibnlMbnBwTWhHR1ZVY25JSk5leHc5d3NlZDRmOSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Mzk5ODI7czoxOiJjIjtpOjE0MDg0Mzk5ODI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408439982),
('59bb30e990878024d6dd81757028bed82eaaa709', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieHc3WE1HMm5RVXRkU0hvQVVYcXlpZ0tjYVlMZlJoY1hocko0M0xWZyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTg2OTQ7czoxOiJjIjtpOjE0MDg0OTg2OTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408498694),
('59bbfa019b6450993c62cd9c49ee88a8c100384f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidkw2aUVpYm9SWjdYeE56M0JYT1JvYmZ4UmZFbjFmdEppQ0F5dVI3MCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDIzODE7czoxOiJjIjtpOjE0MDg0MDIzODE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408402381),
('59d6357b00abf48be1e3a8429f03009e0eeef80e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzdPRnRpZ2hLOGpwUk9PRTZrQU81SUUwZ1dmM1F4VE5VeWF0OVdWTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTMzMjA7czoxOiJjIjtpOjE0MDg0NTMzMjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408453320),
('5ac23b4b743e4fe41e4389926bf1e17e9b266db7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNGxCd2tiOEloQXVkUGVKRkhMZ0t4TkhJMUlxZ3BCWVU5MHAxUExwQiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDM0NDA7czoxOiJjIjtpOjE0MDg0MDM0NDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403440),
('5cabe3c97ee7fa3146525ba21b3021e7b5cdccc9', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT1lXSWZrazlBQmFielBBcmV0cnRqNXY0MGRTT3lBc2oxcE5SVWhTQSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTcyNzI7czoxOiJjIjtpOjE0MDg0NTcyNzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408457272),
('5e7c302a4883ee158a4f75a9501026c44eb348db', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicUhmS2FDMUU0RUd6R1hmbkk0eTdCOWkwSkdySlJrbjVVc0RqVzBSQyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTA5OTU7czoxOiJjIjtpOjE0MDg0NTA5OTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408450995),
('6216b9f95109c71498ade0f3437b883f04be3d53', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNlhleEhIenZJU2QyYTVybXNSYkdLcDNlVk5KZ3lwUmpxazJ2a2xxbiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Njc2MDA7czoxOiJjIjtpOjE0MDg0Njc2MDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408467600),
('625e51b883ac1c874175042767a0e0c19221062e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiemdyRjFNV2w2a3hzVVZwZU9wV1ZqZUJRU1pEZDllQnpRcDhaQ0FEeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDMwOTc7czoxOiJjIjtpOjE0MDg0MDMwOTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403097),
('62a5cf64d98ca5a1e11a6eae0fa7ec04bd2c90ca', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoielVUZWx4U3JucEs5MlBZOExuNUJaVzZ0aTdteXFkbVFhbkl4aWZNeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjUxMDU7czoxOiJjIjtpOjE0MDg0MjUxMDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408425105),
('67293342047377b3e48717cc0d1bc96f5c8a3b62', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSGZ0b3Q0bVNXdDZnbzhsMUFRVFkyOXo0Y0ttaDhFRk5tZXhobnU1dCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDk3ODU7czoxOiJjIjtpOjE0MDg0NDk3ODU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408449785),
('68dd5c98ca1ce41069f2e12b831f392ea544f4d4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTE44YXNUNm15YkpzSE5MNFExMG94VURkSDZ5SmQ4aEdTMlNBQjdKMyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDc5NjA7czoxOiJjIjtpOjE0MDg0NDc5NjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408447960),
('6964aefdbba87abdd5c2b108666b39b473ca7948', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU29tSmVoZTdsYzNxVTFybjI5R3dpS1Q2dFVmVXhNd0c5R0VDVTdNTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTMwMTc7czoxOiJjIjtpOjE0MDg1MTMwMTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408513017),
('6e3e0504dcd13887c3bc628033814087ab0888fa', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTlNVDBranY2OEgwREZDNWJrTWk0ZmJpTGlsNjlyNGJqcWwxN3p5ViI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODIxNDQ7czoxOiJjIjtpOjE0MDg0ODIxNDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408482144),
('714a714ceeaa7da3dcbe037f61b920e98bfc90c2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibTUxczI1RUlpTFV6ZllxUTF5YzJuVFJiV3JDSlR2WjFLejREY3JTVyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTg4NjA7czoxOiJjIjtpOjE0MDg0OTg4NjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408498860),
('7727c5b41c1e4c77e5e42649ce5b93296484c708', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDF4c0VBckpQZU9MYTRmaUM1N0c4T3lPQUJNRDdhYmttTnFVWGxidCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDM1NTQ7czoxOiJjIjtpOjE0MDg0MDM1NTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403554),
('7778853c48ff182ef238b049c538b8f2c4a66f0e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ0JSZzV3NFo1NXdpRE83TG9HNXU3MGczTzBtcVNSc0NxaTczSGlvYSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDM2ODA7czoxOiJjIjtpOjE0MDg0MDM2ODA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403680),
('78dc80b57b9057e5cf014879f45a2305c494c37e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2JLZDBYN3FMUzNJUzZ6U0VOczJMc3o0aDREcVEwenc2V3ZlZ3JZSyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDkzNjQ7czoxOiJjIjtpOjE0MDg0NDkzNjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408449364),
('7a17ca02b433a64f1c560e606f3eda34840c043e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiODQzdURUck04NHRWZmtrRHltdDcybFI0aERoMzFoQ1l0Z1lYT2dQWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDQwNTg7czoxOiJjIjtpOjE0MDg0MDQwNTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408404059),
('7a4f32f174daaae0fce19d1061eb01f50688b8de', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmY0bUhHRmxNSGo5bVBkMDM2RFJ4ZVJyTWVHZjNxaFJ4UkNjWDNxRyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDExMTc7czoxOiJjIjtpOjE0MDg1MDExMTc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408501117),
('7be97673334c035861755f4368ce545f735fdc27', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSENQaEhiWWppb2xFZWNYNTIyb01zZHF0Q3lUMVV5Q0lIV3BJck9jSSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDQzMTY7czoxOiJjIjtpOjE0MDg1MDQzMTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408504316),
('7cb820985a7be72cf7345e43d9393fc98b7787bd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSW5PU3Q3NFJ0dHUyY21FZ1B5SlpoRndteEdSYk91MW5odFZQWE1SMCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODQzNTkwMjtzOjE6ImMiO2k6MTQwODQzMjg0MztzOjE6ImwiO3M6MToiMCI7fX0=', 1408435902),
('7eaab145b00042101c166014c660e4eaaa7c525b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZGNFeXZSdHZ5YVM3azA4ZGNNZlAzdXhsM1FXQng1dkUxeW5pZWtONCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDI5NTk7czoxOiJjIjtpOjE0MDg0MDI5NTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408402960),
('811ef1a92795acaf54b1a91e76a4b1cec719b072', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlYxMHJBbnczS0lMblV2VUxDUUlSdjdVeFlmajNMMUoxdlA5MzR4NyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NzA0NjA7czoxOiJjIjtpOjE0MDg0NzA0NjA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408470460),
('8149a8334941a0634fa5f29e92987bb4ec06b788', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicUFYMGNyWG9QZHlSdTQ0MFUxRHFNS3VVYXh2dEJBdUY2d1lBVXBjYyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTc0NDc7czoxOiJjIjtpOjE0MDg0NTc0NDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408457447),
('81a46c6bf993e935e8c1061f3937db0240ceef65', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOEJRamVoQmtRRVB4NTRSeUZNRHVlb0FlYU1YNXFEaEkyTk9tWUdVOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NzY2Mzk7czoxOiJjIjtpOjE0MDg0NzY2Mzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408476639),
('81f5869043600ee7c202d6b759fa15f65dd568a4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnJGb3VJQmFNUUd5akxtM2xnaDhNUERkQ2w2SUFyYUZ6MEFrYXQwRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTYwMTI7czoxOiJjIjtpOjE0MDg0MTYwMTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408416012),
('82eaea1b1844f087b7329b04e0b88ca4cf603022', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmhacW5qUkpZMzR2bEV5MExlTGVPNWphWlhJcUxFTlNqYVl3ak1nbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDQxMjQ7czoxOiJjIjtpOjE0MDg0MDQxMjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408404124),
('87d87c22e6af226df733e67ca0e26c5e1ed76413', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMW9sRGlMQ0NKd243UWFVeDJtVUgwVkhYRFlBd2tEa0ZqdlgyNlNreCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODg2MjU7czoxOiJjIjtpOjE0MDg0ODg2MjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408488625),
('89ea0d538f3f5d689cb1b9a9b6f60e7f70aa67e3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiakdjN2lQT2d5Y0FtSDg2OHR0dWR5Rk9FSHJreWZYWExqeDRUYlhCNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTI3ODQ7czoxOiJjIjtpOjE0MDg0OTI3ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408492784),
('89efea14e2420a73e27c642d7bc28c36a94ef906', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWjR2ZVoyYVZWcWtZMVlHYXFQa1pueVA0aXRST0xsQU1YdzR1QVBQcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjEwMDg7czoxOiJjIjtpOjE0MDg1MjEwMDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408521008),
('8b39fff3bca4cad5e63c7fc378ce776d16b1ba30', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieUpPYVZidUZ4cnRyeWRGYVZYcTl0bHNDVm01QndLWXkxZFdIUTNZcCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTYwNzY7czoxOiJjIjtpOjE0MDg1MTYwNzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408516076),
('8c0952d360394cbe8cdda2bb6397429e6d19656e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS1hBTFlvSjVmWmtzSk5DbVhyOFhDVzlTSE1ybm1iSFhZRWVGR2E1QyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjIwMzE7czoxOiJjIjtpOjE0MDg0MjIwMzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408422031),
('8d7ac93fe2c5d67e7f818a9452d2f9ccdeb917b7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkRZaWJKcjRLQ0tRQzVGV0hmdU8zU2RURGVhU1Vpd1lIczZpVHY4cCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDE5NzE7czoxOiJjIjtpOjE0MDg0MDE5NzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408401971),
('907fc013c9f2d712d2db3330748a57a911bb5a0f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiemRwSW9hbTEycGFSdHVORGR4b3VkelVjRVVlUUhScWtKQVhtdmZTbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDA4OTA7czoxOiJjIjtpOjE0MDg0MDA4OTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408400890),
('9113b6df0b2862f8ef8ea3a1ec87c5a41601a0d1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVlRwOGd1ZXRyN2Q0Mko4eEZ4RnNsUW5PRDkxQWJ1eHdJNHZRZ2E3QyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTQwMDY7czoxOiJjIjtpOjE0MDg0NTQwMDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408454006),
('9230803519f5a0556db4ccf079482e03fbe5a303', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTcwb2NURzRUNkppc2N2cVFRY0x6NWVFdmJWQVJ3dkhJV1FDazRWcCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDMxMTU7czoxOiJjIjtpOjE0MDg0MDMxMTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403115),
('929c0bb249f34770c6d744d206ed4aeb6e536494', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoia0dyZVVJZ3JMQmhVS3VwbkhhaFN0RVpPaVcxam5wZjJmV015bTF0WCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzOTkwODg7czoxOiJjIjtpOjE0MDgzOTkwODg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408399088),
('92fafdb9d601e8f84a65d998def715090d41d6e2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ0tzaEE4NENJVm5OeXJXUzE5TFdxNXpINEVFRjFuYVo1T1VEWDVrTiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzIyOTA7czoxOiJjIjtpOjE0MDg0MzIyOTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408432290),
('93a0993f36d9ba1698b360e3e133556997c1998f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNmh3VTN3b1lhb25PT2thM3U4a1ZqYnpIQ00xOWZtMzVLVzNCWGtiaSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTA5OTQ7czoxOiJjIjtpOjE0MDg0NTA5OTQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408450995),
('9466ec8ba0368b4026e3e08e984f23dc8d75aa12', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYVFjZEsycXdHMGtVRkZuMDV6bFFrNmNEdkNHWGZEZFU5R3VRVFVLMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjMxNzE7czoxOiJjIjtpOjE0MDg0NjMxNzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408463171),
('94e5f8132c4cae4ac41b95eefd7a8a0bd1ef0759', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQmJOREpCM3Fma1JTV2lkNHBreFA1Qm9nZHJZSlZGNUVlZDg2Y3VCTyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Njg3Nzc7czoxOiJjIjtpOjE0MDg0Njg3Nzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408468777),
('95f61fb06e076f68c393ef09abdc3620635aae52', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNlNOQVd5Z3d1amtTN1VYQ3hhZ1k0OFEwTkNPMmVSOEtNVkxINTRrUCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDM0MTM7czoxOiJjIjtpOjE0MDg0NDM0MTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408443413),
('96991044203734c1a79312ec3bbc64fe8430aea0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZmxvaWxmQ3JvUE00MW1BREVOc3FnY0FNVHhBNUFNcFExT2I0bHBPViI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDAwNDU7czoxOiJjIjtpOjE0MDg1MDAwNDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408500045),
('9702d48079d9a290e404aa504e6a7d7e5a51dcc5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWlVU1JLNzJqT1ptc01zSzJNOTNKU2dWTW80UXVIRTV0QzFnTFBFTyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjE2NDg7czoxOiJjIjtpOjE0MDg0MjE2NDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408421648),
('9ba22249129f15d126dae074a550e522caf52f02', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMWp1UUpiZVpLMHdHVXVqbVZaSVBERTNmeGhyR0lpUkwxWjlZUVBycyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTI1MDg7czoxOiJjIjtpOjE0MDg0NTI1MDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408452508),
('9bd36224cff4fef536602117735eae0391665382', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzZLUjJIaDM4Njc1MVJIU205SmZWRkdYYkk1VGtyczQwSE1OVFZodCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NzgzMDA7czoxOiJjIjtpOjE0MDg0NzgzMDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408478300),
('9d38d500b29fa2b0651fbfe495d126bb92582d57', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVEZnSlpsVWxPOEVKOUg5R2MyMjBMemZUaFFiMnY2MUhDSUh4bUQ1bCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjE0NTI7czoxOiJjIjtpOjE0MDg1MjE0NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408521452),
('a0c0a61be6a89b54c37b0f4eefafeb6616883234', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMjRTNnJnYm5lQmdDc25wSGdVUzlKNkpSUnNEMXBobFZodVd1TWhGbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTcwNTU7czoxOiJjIjtpOjE0MDg0NTcwNTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408457055),
('a0c8980e1f14d5d9202a5bf33cf6f5c9cdb221b6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNWxxdTVWV1BXRTgzZXYzRjI3MFhXOXRoWkJERkpjM2IxSlZPTmZNRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTI1Mzg7czoxOiJjIjtpOjE0MDg1MTI1Mzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408512538),
('a2166e0f05ea157d3107422e55ebd07d7edc6385', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWNWUTRESHlDb2E5WkpBczBFSzk2emxqc0ZkMWZBOVFIM2JQSFBDbyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDQ5NDU7czoxOiJjIjtpOjE0MDg0NDQ5NDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408444945),
('a267ce2231c13e323b2e09d781025b8107ea9c80', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieUJBa1E0bGkzRWh1Z2RFZGVyZzFNcHZWQ1RoaDRBU2hxTHJGN3ppayI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzQzMTg7czoxOiJjIjtpOjE0MDg0MzQzMTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408434319),
('a59879062832f5de0974647b3b1e4e88932208de', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiREtQUWU3ajdnMmJGVU1xUDJmYWdMcnkxSGdZQkl0bE5xRFpBYkJucyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzUxNzU7czoxOiJjIjtpOjE0MDg0MzUxNzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408435175),
('a65568349a3ea1ef7469c2ae508c1c90db17c650', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWHNNRlRnUmlRcUtCamVkT2FzMEF2NlRTOUZLZmc1ZmYycHJ6SVhaaiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTAzNjQ7czoxOiJjIjtpOjE0MDg1MTAzNjQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408510364),
('a6b962c30324ed2c335e3199bba58524c2db84ae', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXlJMk1mNnNPZTJDaFF0WmlpTVZkTmdZd25veEpCOUxTSzBrYnROSiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjU2OTA7czoxOiJjIjtpOjE0MDg0NjU2OTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408465690),
('a93458c1c1b35751373966d926627c90c2c2aa66', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXRDaUhEZmY1S0JXeXl1Q1l2eVl4YnVNeFQ2c25DakJRQkQ5ajNneiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTcxMDQ7czoxOiJjIjtpOjE0MDg0OTcxMDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408497104),
('aafb4edc9ee5b3c08a112cb14f56cb277a967a2d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTVteHM4OEozeDU5QU9hYjZQQ3UzWkJRN25pREJQaXZIb2x5ZXUxViI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTQ0NjI7czoxOiJjIjtpOjE0MDg0NTQ0NjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408454463),
('acedd131f6a742737238f8d8a6153bf8c42db6b5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUWJ6MnZMUzg3T09saFhrVzlTN25RUXlsMDRDVk5RZFRDNFN0UlFGZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Nzc1MTg7czoxOiJjIjtpOjE0MDg0Nzc1MTg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408477518),
('ada67156632340a8102046d54f02ec412d884586', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZFpMT2JQSjNtZ2Z4TjhaVTU3S215SXQxQmlRSVJ3YkFVeGsyS0FpNyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NzMxMjU7czoxOiJjIjtpOjE0MDg0NzMxMjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408473125),
('ada6d73342ff9be889eadaf07c583510cf910b04', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzRUclhGVHo3U3pBNmwzdklnRmYwNW9VMFdhQVRNckJ0WDBuZ2pyeiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTA2OTk7czoxOiJjIjtpOjE0MDg0MTA2OTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408410699),
('af30a406bb9246334b4b3e2c95f6f903870ecd6a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXJCcVFsQ1lkbkNFYUNvRkt2aUVvbUlNRkJuU3lKZjBSaHQ2c2ZqeSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTI2NDg7czoxOiJjIjtpOjE0MDg1MTI2NDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408512648),
('af3fc0b40237e6acc1f95fe32648be92fe2ea140', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYXNuaVlRYXlUM3ZsTW1yYzViMjZIY3VnVVBjVDFTb3FZenJwa2tTNSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDM4NDg7czoxOiJjIjtpOjE0MDg0MDM4NDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408403848),
('b050fdbd6cca2f06600c9b8b430ecf6fba066175', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2c2cUU4SWd4N1lBcDNQNDNFUnFtRGpxc0hQVHdVOVlBa0NDbWNueiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTkxNzQ7czoxOiJjIjtpOjE0MDg0MTkxNzQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408419174),
('b173a5d73e09937e540e12d712ae10d52c0a2f32', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmYyeWRrMUR1OGFjYjJxajBnUW5URkhjV3JxZWxOUXl6Y3VwWWhNSCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTc4ODM7czoxOiJjIjtpOjE0MDg0NTc4ODM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408457883),
('b27eeee2ab03fc16913de326cdc5bfe3c5acee30', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVm53MnVsNGdBY0d0TnhuVUJzRU1oSHVFdGRDRWJrSnVldEsySm1udiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjcwOTA7czoxOiJjIjtpOjE0MDg0MjcwOTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408427090),
('b3bbf30c14af559c8c4afb4608b413430bc6240a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoib1EwS09BQWNaVDc3cGRMdENMQVRxTjZmdDVNeEV2dGk3Yjc3VDJyWSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTU4NzA7czoxOiJjIjtpOjE0MDg0NTU4NzA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408455870),
('b4223a5e2b7218ee4f5f7ab4ad3a2035fa23ef2f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN21HTmV1N1ZIcWtPbEFiUjdCdHZpa0Z2Yk94dTBoMlJCZ01JcUZNcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTkzMDQ7czoxOiJjIjtpOjE0MDg0OTkzMDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408499304),
('b58ba8970cd56de951992e370a7ce0e30b70d567', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWlFSa21HbjAwbTQyV05sdXViTXZ4cGJHTjhMaEJoZUs3N2tzejduZSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzMyNzU7czoxOiJjIjtpOjE0MDg0MzMyNzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408433275),
('b68bb10cfe69aa0e757f39f3bd6fbd52978c501b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkpOUmZmRlhUdE5xZzFyNU9CblBtWWZ2VzRCWHNaN0dFc21zQ2lLYiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzU3MjY7czoxOiJjIjtpOjE0MDg0MzU3MjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408435726),
('b7a39e1fe7336dbee973711e8cb5f30867b0b88c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieHlUZVhTbUQxSmNQekI0RXBWeWhaNzdHSVdvNWVsU0RNMUFCNDBVTyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzOTk2MzM7czoxOiJjIjtpOjE0MDgzOTk2MzM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408399633),
('b86d55c59ae55af2c4e9024d9d3bf4415e89d6f0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiajNLOG93Y2VuRVh4QklFNTk5NWxBS240YldsQzJTaW00b2FnVVpyNiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDk4MjY7czoxOiJjIjtpOjE0MDg1MDk4MjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408509826),
('bb2963939b3fdeb3dcf7f29b9b92302ff4b02ceb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidGlQdEg5NVR2YWl0bkdoaUhoaDFFaW9YWDVXakpjR1k2NGZCNEE5SyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTU2NDk7czoxOiJjIjtpOjE0MDg0OTU2NDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408495649),
('c112e6d2e5c819156546fde10ac22176516cffb0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNGx2ZkprYjd4elZQZ2JCNWNBSGFXd0lkUjdaY3IyNGgzbFVuTjdVYyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTkyMzg7czoxOiJjIjtpOjE0MDg0MTkyMzg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408419238),
('c1c50b153b264a65ba37a4d9462deed6de200af6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWVieWVqNEtMNGxkaXFsTFdGUnR6aHZMRVBkd0lkSDJ2NEs4V21qbiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDE5MzU7czoxOiJjIjtpOjE0MDg0MDE5MzU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408401935),
('c1eed504ca763e2ca23610977e43fe2ecfd31629', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibGJNeWdXZ3VTaFJpcG0yalgzMHg3Rnd6OUxCTVZ5NmtOMHVHYm9HcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTAyNTU7czoxOiJjIjtpOjE0MDg0MTAyNTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408410255),
('c324c8f9c80c66a9f1d5ddd96e1bbba6893e0488', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYURUMVBoalZJZWFZRHFidTg4MEdpYkRQeVJBdnBtazRnUTZVbkg3UiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MTI2NTM7czoxOiJjIjtpOjE0MDg1MTI2NTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408512653),
('c40ec987b1a0dc5fd34c391381ff28785411a66f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlA5cGI2TDhVWVZISEpYTGU5eGd0Y1VsUVhOSHVFZVRpY01DRHZXTiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjMxNjk7czoxOiJjIjtpOjE0MDg0NjMxNjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408463169),
('c6b91641a907f41b3fef40140f1d1a5d42a9b48e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidUE3cVNhSDRDNjJoaFBkT3REWkJuSzZyeVVxODg3WHA3bWtvMjZaTSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Njk3MTM7czoxOiJjIjtpOjE0MDg0Njk3MTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408469713),
('c75279657843ba4a9e95317a6516a66c85a2eea4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiN29KR3BZcExwNkFsU0NoYkI3cTE3VEt0NVBuMHpvRTVIUnE0RzNzVyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODk4NjI7czoxOiJjIjtpOjE0MDg0ODk4NjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408489862),
('c79c4b5e8d9d4cef10af740ec1b387747e79cae8', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibzE3ODJiaHUzbVBmeHZMdnRyQk43c0JDMkpjMXBTb0hYWVpxSlpkTCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODQ1MTg3NTtzOjE6ImMiO2k6MTQwODQ1MTg3NDtzOjE6ImwiO3M6MToiMCI7fX0=', 1408451875),
('cb202834f566bb394cdc8640ac402a4da83e9551', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR2NLY1JrcXM2WDNUV2NSSkl6TTFCcVg4T3pESzFYUlVHQTNCdWw3cSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDQyNTI7czoxOiJjIjtpOjE0MDg0MDQyNTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408404252),
('cf2f65a60ab86e0633cc6cee35d8970539ca77d5', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUdmaTVtTExXcGZ5TUZadG0zSEt1RlhJbVBpSVpYOXpFSThvdnF3WSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MjA1MDE7czoxOiJjIjtpOjE0MDg0MjA1MDE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408420501),
('d57977d8cfc745a8f4813fe91bddc48cf3d792e6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWWVURHpKdGx0T3FWcHRhM2cyMFdtOGExZGxrY2gwRk5nOVlnNlNrRCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTUxNzc7czoxOiJjIjtpOjE0MDg0NTUxNzc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408455177),
('d5ccd594e6898d3fb3870f4a68b116d50749c342', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVldnRE5tN1FYOXl1UDZ0WVhaMDBWa1hyQVdOSmJMOExxQTVRaW1CZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Mzg4NjY7czoxOiJjIjtpOjE0MDg0Mzg4NjY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408438866),
('d6c8734c0adbc7dbed391f6402b4fa4504b31b28', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVjZsZ0VpWVNvVzk1Yms0TXdVYkVucTEydnZhaU44VTRPVTRPQ2dibyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDQwMTE7czoxOiJjIjtpOjE0MDg0NDQwMTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408444011),
('d74a1943c5259d9568e94bf309af7c8fc0b5e220', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU1RiV2hsTjRTMDlhTXhITlREdmxMcnhCRkI0Y2huMWw5N1dkelBMZCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDQ3MjU7czoxOiJjIjtpOjE0MDg0NDQ3MjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408444725),
('d86cfe4c76ecf191a515b0b8e74b1e3f681d3103', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTjdIaWM1VW1jRGh0aWhUQUVkcElidXBSZHhiVFlPdGx5OUI1WDdSTCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDAxNzE7czoxOiJjIjtpOjE0MDg1MDAxNzE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408500171),
('d8b10e0f948e321799fa5a8802c329d9cdd3b876', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkZieFlTcFpWVU9tRUlnQnZiRFdJZUJtb1g0V0J6Q0E2ZXVyVGEwUyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjczNTY7czoxOiJjIjtpOjE0MDg0NjczNTY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408467356),
('d9d6a7ecba52ec27591634937487d4f55627cb00', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUElSYTN1NFZCdThqV2t2bHNaNEtpMEFjdEg1d2hqZmwwNzBqZkc0WCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTk1MzI7czoxOiJjIjtpOjE0MDg0NTk1MzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408459532),
('daaf29bf99d54f08b452852ce9d175d625c245b6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicDNGWjBYWWNORkZoZGladW5LbEg1d09DY1RYNnJPV1FxVFJBZHp2WSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODk1MTM7czoxOiJjIjtpOjE0MDg0ODk1MTM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408489513),
('dd90fc4bd1adae34c424084ec65990f94def259b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU2ZMY3NNc1NHQXI0eTViMThaYVlxNGkybE5pTTZvYmlxaktsM1JUNSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTM2Njg7czoxOiJjIjtpOjE0MDg0MTM2Njg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408413668),
('ddd3eaa7eed6b21d8a810b35004256cd3de4937b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR3NIVFZxOTBpUzdqYmRYRmVad1dEMnJNM1pJMFQySlhwTktzUDhsaiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODA3MjI7czoxOiJjIjtpOjE0MDg0ODA3MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408480722),
('dfcc021b4f06af0049fc1aeb30af2e4169d7dcad', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieGlVc2FHSHJkQWE2UUwyRno2c21uYndTWFlvZ0lRQUtob0Vsb3B1eSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Mjg2MjM7czoxOiJjIjtpOjE0MDg0Mjg2MjM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408428623),
('e14341e545e814f5277b9b5f669d58db9880824e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNWVkYmJSTEhvMmtEeU9kY3FHcGNoTlhhM2c5Y0hGc2NxOW04ZFBORiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTQ0MjU7czoxOiJjIjtpOjE0MDg0NTQ0MjU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408454425);
INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('e17833e84525456052e4d178e793e71ce3ed8d6d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid0hTSWFFSnhsZ3dxUVAwQ2lXaUswRHoxODVXeW1PRzl4aUhMMFhaOSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NzY4NDk7czoxOiJjIjtpOjE0MDg0NzY4NDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408476849),
('e21e1bd249af85ab044735a6836cf42474989535', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVllvWjE2Z1M1WGFkQUU2ZnlrR2ZUQk5MY2cydVNKUktFS3NZWGFvaSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MTkxMDc7czoxOiJjIjtpOjE0MDg0MTkxMDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408419107),
('e45b296529af6ead4dc87c7d59b91a8a8c99c918', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibThrbDBucDlLazFPVTFNdGVkZmxIcmZ2MXdEVHNuUVVSaDRuaUUxbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzE1ODQ7czoxOiJjIjtpOjE0MDg0MzE1ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408431584),
('e469fa04f3fb2b9b6dcde561d7be0c209a9672c4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3FSbEYyeUNNZkxWYjdnbUNmT0wycHd4YlQwd041alJuRURpSzFpUyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjczMDM7czoxOiJjIjtpOjE0MDg0NjczMDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408467303),
('e4c64fb4045c5e7ec359b9f3b8cfede713b9e1f4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlVzSmFyQ2dsN1ZDUU5nTmd1ZzVYY2QxU0JVRDQyQjJIRjQwbmZsTiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjE1NTI7czoxOiJjIjtpOjE0MDg1MjE1NTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408521552),
('e72e3aca7ad214ae5e910c0fa72d504d32f70be6', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkwxdmxlQzZDcFRLNXBzTERIVFE5NHZoaTE3TUZyTmRJYTlkVGU1eCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Mzk5ODQ7czoxOiJjIjtpOjE0MDg0Mzk5ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408439984),
('e775bcdd5d0b9868b760389807ab5d1f2563ad8f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoielZnUUhwWnRUcGlwcTh6U1VVUTFzTUJhWFJta1F4UGVESnVyNXI1WSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTAxODY7czoxOiJjIjtpOjE0MDg0OTAxODY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408490186),
('e9d04b65670f948f3f2deaff369c6992b52f31e3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic1pscnB0UWZieDl4VE84eDJTVExxcE5RYlhOOGpFNWN5RWdxRExQOSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDgzOTgyNTU7czoxOiJjIjtpOjE0MDgzOTgyNTU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408398255),
('ec6791497ae5a908568bbc6788ec33aface8c6dd', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEo5MHgzUFRsSmdwSkVGVEVwV2s3ejdDcDNJbmVLNWtMSW96OVFXRSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDU1NDQ7czoxOiJjIjtpOjE0MDg0MDU1NDQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408405544),
('ed8f00db3a897692a17f186e48167da529ce9a5d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicHB3YWJkVHRGT2N4UnpLcGwzZlp6TEF1bEJuZTIwcHQ5bnVMT2xBbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTM1NDk7czoxOiJjIjtpOjE0MDg0NTM1NDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408453549),
('ef03cc7ea717a1044c0c3d752f1d0473e3fc386c', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRlNVcHBVQlVma2NJTDI0WjZNVUhlbUhZWHVxUVI0UmdVWnNkRGdkcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjUzNTE7czoxOiJjIjtpOjE0MDg0NjUzNTE7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408465352),
('efa39836e25a6f988b41f72d293dc88a9c5dbf80', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidUFGZWt0c0ZvOVVXeWM5Y0ZKU2pCWU14aUNUd1JoSTVZSXdPeUdWOCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODc2Nzk7czoxOiJjIjtpOjE0MDg0ODc2Nzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408487679),
('f27072efabb1c024030f43ff1e91548e492520e1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTjc3M1ZpNHVvZDBoSzc0S1lRd1VmZkR2UktlcHlKOFlRSFJCNnZyRiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDI1OTA7czoxOiJjIjtpOjE0MDg0MDI1OTA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408402590),
('f39b8ceca87ea2e8583df443aac9a107882e31c3', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXEzNDBnMjk4VnQzVVBIM3E2bWZvUnpUNWlIcXJpQ0NHQnhJbVZaUiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MDQzMjk7czoxOiJjIjtpOjE0MDg1MDQzMjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408504329),
('f80fd9b9056629cacc9dacf2118c7036c7f8a469', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoid3FJMFNySU9RaUJxQVU3VVVUNkhOVU40MVFFZGhXcWs5c1dKT2xRUSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjQ1Mjk7czoxOiJjIjtpOjE0MDg0NjQ1Mjk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408464529),
('f8bce85b4bb5330f9d305570e18fffc0c8646bdb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUEc2WTh1MmR0NG1kN2pzOWFjTks4SjhxNG9pVUFxTEhwVTNPYzluVCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwODQ1NzQwNDtzOjE6ImMiO2k6MTQwODQ1NzM0ODtzOjE6ImwiO3M6MToiMCI7fX0=', 1408457404),
('f99255b118a30ab047f6e785d83651d845efcd8d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUxVSlB2RkRON24zdnlNY3JOdDRKT01RZ0dEZXNSbmtrMmVpb0VtMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0Nzg1OTI7czoxOiJjIjtpOjE0MDg0Nzg1OTI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408478592),
('fa067f5cdaf1b84589dfbe9e2254bd8ca7325aa2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiajRIckMwMXVKZVVsc0NNVUd3SXR3WnVLUFVFbnVSYldBVXR3UDB2MyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg1MjE2Mjc7czoxOiJjIjtpOjE0MDg1MjE2Mjc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408521627),
('fb7e9e4cb9c3f67fa6a6499d8a45ae18aec62f06', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnlYaDdYU1RUcmRtbEl5cjhtM0ZWZDRDT3F5clBoMWY5eFNyelNRbCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0ODc1MDU7czoxOiJjIjtpOjE0MDg0ODc1MDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408487505),
('fb861131b22b289828b8c7ce5fc3b9140651548a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiamN4VUlJUUJvMkF4SlhXTkFndkYzSmhGYzJ6ZDd4V1VoSjR2TW50OCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NTY1MzY7czoxOiJjIjtpOjE0MDg0NTY1MzY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408456537),
('fc9a1254cc0f042bad66e3ca42a36ad99a263ae2', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVV3Rko5VUI4eExBQmNpaTM3OUdOWkdSc3FBUEhiR0lVWDFuN3dPYiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MDkzNDg7czoxOiJjIjtpOjE0MDg0MDkzNDg7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408409348),
('fd5d0a2ed5822d8058b927860abf08ae9352b522', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTlFLMUFPQ1M3MjlXQXhmaXFJbkhNSkMwVWxFdHJTcURzdUtwM3QzWiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0MzI3NzI7czoxOiJjIjtpOjE0MDg0MzI3NzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408432772),
('fdc13396b9556debf482589beac5760b2dca6831', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkpBZ3JqWTV3S09oUno1d294aVFVVUJIeEJLdXAzclEzbmg4aDlPMCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0OTgxMzI7czoxOiJjIjtpOjE0MDg0OTgxMzI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408498132),
('fde72e6c3ca184b5ffdb4a1f9d3083da777e8b81', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYkJFUzZSSWJPR3UzU0NDYmpDdVlHTTBxcjhTekIzU0Z5dTJaQjZ1QiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NjY0Mjc7czoxOiJjIjtpOjE0MDg0NjY0Mjc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408466427),
('feeb08a72908a78adf9120c0954ee995e1967fc0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic2ttTmxacm5HWDVXbTNvelVVcGhveFFWVlVGWUZBdndueHBHdW54RCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDg0NDI3Nzk7czoxOiJjIjtpOjE0MDg0NDI3Nzk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1408442779);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-07-07 14:32:27', '2014-07-07 14:32:27');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `tag` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_module_unit_id_tag_unique` (`module`,`unit_id`,`tag`),
  KEY `tags_module_index` (`module`),
  KEY `tags_module_unit_id_index` (`module`,`unit_id`),
  KEY `tags_tag_index` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@lessad.ru', 1, '$2y$10$h4Il0sgQtQVK5kW0zdLraOG5hYHNyHbZRqXvIXkgddLsJZ7jkpgwC', '', '', '', 0, 'PscKmsDJCAzBeQcC5BYaMEWdQ5kqBchszPvOM0FUT5vqRVZBmneAxVnTSy6C', '2014-07-07 14:32:27', '2014-07-07 14:40:39'),
(2, 2, 'Пользователь', '', 'user@lessad.ru', 1, '$2y$10$Li7WTdg7N6YVtD2S1rQSmeHDLm3AKBnwvgPz5Ymh8jZedSYGs1vwa', '', '', '', 0, NULL, '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(3, 3, 'Модератор', '', 'moder@lessad.ru', 1, '$2y$10$T6ncASnknrjq.AjcBzSERuH96ZPhcjYJgnJyUjd8nQ08buWlUXxli', '', '', '', 0, NULL, '2014-07-07 14:32:27', '2014-07-07 14:32:27');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
