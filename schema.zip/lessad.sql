-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 23 2014 г., 08:44
-- Версия сервера: 5.5.37
-- Версия PHP: 5.5.12-2+deb.sury.org~precise+1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `lessad`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `channels`
--

DROP TABLE IF EXISTS `channels`;
CREATE TABLE IF NOT EXISTS `channels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short` text COLLATE utf8_unicode_ci,
  `desc` text COLLATE utf8_unicode_ci,
  `file` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `channels`
--

INSERT INTO `channels` (`id`, `category_id`, `template`, `title`, `link`, `short`, `desc`, `file`, `image_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(4, 2, 'publication', 'Садовникова Т.П. Способ защиты древесины хвойных пород.', '', 'Авторское свидетельство № 1655360, 1088.', '', NULL, 0, 0, '2014-07-21 10:47:31', '2014-07-21 10:47:31'),
(5, 2, 'publication', 'Садовникова Т.П. Особенности применения аттрактантов короеда типографа в условиях Урала.', '', 'Ученые записки Тартуского Государственного Универститета 616, 1983, с.67–68.', '', NULL, 0, 0, '2014-07-21 10:48:57', '2014-07-21 10:48:57'),
(6, 2, 'publication', 'Садовникова Т.П., Кутеев Ф.С. Метод оперативного определения численности короеда типографа с помощью аттрактантов.', '', 'Журнал «Лесное зхозяйство» № 12, 1983, с. 51–52.', '', NULL, 0, 0, '2014-07-21 10:49:46', '2014-07-21 10:49:46'),
(7, 2, 'publication', 'Садовникова Т.П. Короед типограф и меры борьбы с ним.', '', 'Информационный бюллетень ВПРС МОББ, 41, Материалы докладов Международного симпозиума «Защита растений — проблемы и перспективы», Кишинев, 30–31 октября 2012, с.127–129.', '', NULL, 0, 0, '2014-07-21 10:51:07', '2014-07-21 10:51:07'),
(8, 1, 'documents', 'Открытое обращение в комитет лесного хозяйства Московской области', '', '0.9 МБ', '', '/uploads/1405942954_1146.pdf', 12, 0, '2014-07-21 11:39:36', '2014-07-21 11:42:34'),
(9, 1, 'documents', 'А.М. Жуков, Ю.И. Гниненко «Опасные малоизученные болезни хвойных пород в лесах России»', '', '10.5 МБ', '', '/uploads/1405947140_1773.pdf', 20, 0, '2014-07-21 12:52:20', '2014-07-21 12:58:10'),
(11, 1, 'documents', 'Я.Б. Мордкович «Насекомые в нашем доме»', '', '14.8 МБ', '', '/uploads/1405947611_1201.pdf', 22, 0, '2014-07-21 13:00:11', '2014-07-21 13:03:55'),
(12, 1, 'documents', 'А.Д. Маслов «Короед-типограф и усыхание еловых лесов»', '', '5.4 МБ', '', '/uploads/1405949074_1838.pdf', 23, 0, '2014-07-21 13:24:34', '2014-07-21 13:24:34');

-- --------------------------------------------------------

--
-- Структура таблицы `channel_category`
--

DROP TABLE IF EXISTS `channel_category`;
CREATE TABLE IF NOT EXISTS `channel_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `channel_category`
--

INSERT INTO `channel_category` (`id`, `title`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Документы', NULL, '2014-07-15 09:26:20', '2014-07-15 09:26:20'),
(2, 'Публикации', NULL, '2014-07-15 09:26:27', '2014-07-15 09:26:27');

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(2, 'user', 'Пользователи', '', '', '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(3, 'moderator', 'Модераторы', 'admin', '', '2014-07-07 14:32:27', '2014-07-07 14:32:27');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news`
--

DROP TABLE IF EXISTS `i18n_news`;
CREATE TABLE IF NOT EXISTS `i18n_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `i18n_news_publication_index` (`publication`),
  KEY `i18n_news_published_at_index` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_news_meta`
--

DROP TABLE IF EXISTS `i18n_news_meta`;
CREATE TABLE IF NOT EXISTS `i18n_news_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `news_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_news_meta_news_id_index` (`news_id`),
  KEY `i18n_news_meta_language_index` (`language`),
  KEY `i18n_news_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages`
--

DROP TABLE IF EXISTS `i18n_pages`;
CREATE TABLE IF NOT EXISTS `i18n_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT '0',
  `in_menu` tinyint(1) unsigned DEFAULT '0',
  `sort_menu` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_publication_index` (`publication`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `i18n_pages`
--

INSERT INTO `i18n_pages` (`id`, `slug`, `template`, `publication`, `start_page`, `in_menu`, `sort_menu`, `created_at`, `updated_at`) VALUES
(1, '', 'index', 1, 1, 0, 74, '2014-07-09 11:36:55', '2014-07-22 11:58:45'),
(2, 'about', 'about', 1, 0, 0, 12, '2014-07-09 11:37:21', '2014-07-15 09:31:27'),
(3, 'catalog', 'catalog', 1, 0, 0, 9, '2014-07-09 11:37:34', '2014-07-15 09:29:22'),
(4, 'experience', 'default', 1, 0, 0, 72, '2014-07-09 11:37:49', '2014-07-22 11:51:10'),
(5, 'contacts', 'contacts', 1, 0, 0, 13, '2014-07-09 11:38:06', '2014-07-15 09:31:55'),
(6, 'meropriyatia-po-borbe-s-vrednumi-organizmami', 'default', 1, 0, 0, 6, '2014-07-15 09:28:47', '2014-07-15 09:28:47'),
(7, 'search', 'search', 1, 0, 0, 15, '2014-07-15 12:57:13', '2014-07-15 13:04:34'),
(9, 'savoi-1', 'default', 1, 0, 0, 42, '2014-07-21 10:59:09', '2014-07-22 07:16:06'),
(11, 'pervaya-massovaya-obrabotka-eli-v-podmoskove', 'default', 1, 0, 0, 54, '2014-07-22 09:21:39', '2014-07-22 09:46:57'),
(12, 'lechenie-vekovogo-duba-v-usadbe-griboedova', 'default', 1, 0, 0, 56, '2014-07-22 09:46:45', '2014-07-22 10:24:20'),
(13, 'obrabotka-kusta-ivy-sredstvom-savoiy-1', 'default', 1, 0, 0, 59, '2014-07-22 11:11:10', '2014-07-22 11:17:47');

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_pages_meta`
--

DROP TABLE IF EXISTS `i18n_pages_meta`;
CREATE TABLE IF NOT EXISTS `i18n_pages_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_id` int(10) unsigned DEFAULT '0',
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `seo_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8_unicode_ci,
  `seo_keywords` text COLLATE utf8_unicode_ci,
  `seo_h1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `i18n_pages_meta_page_id_index` (`page_id`),
  KEY `i18n_pages_meta_language_index` (`language`),
  KEY `i18n_pages_meta_seo_url_index` (`seo_url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `i18n_pages_meta`
--

INSERT INTO `i18n_pages_meta` (`id`, `page_id`, `language`, `name`, `content`, `seo_url`, `seo_title`, `seo_description`, `seo_keywords`, `seo_h1`, `created_at`, `updated_at`) VALUES
(1, 1, 'ru', 'Главная', '<div class="wrapper">\n	<div class="main-info">\n		<div>\n			<div class="info-circle" data-id="care">\n			</div>\n			<div class="info-circle" data-id="young">\n			</div>\n			<div class="info-circle" data-id="defend">\n			</div>\n			<div class="info-circle" data-id="rest">\n			</div>\n		</div>\n		<div>\n			<div class="info-block" data-id="young">\n				<div class="title">\n					      Омоложение\n				</div>\n				<div class="desc">\n					                                           Сад обычно сохраняет хорошее плодоношение до 30 лет. Защита деревьев от болезней и вредителей, от насекомых.\n				</div>\n			</div>\n			<div class="info-block" data-id="defend">\n				<div class="title">\n					      Защита\n				</div>\n				<div class="desc">\n					                                           Защита деревьев от болезней и вредителей, от насекомых.\n				</div>\n			</div>\n			<div class="info-block" data-id="care">\n				<div class="title">\n					      Лечение\n				</div>\n				<div class="desc">\n					                                           Различные методы борьбы с короедами. Защита деревьев от болезней и вредителей, от насекомых.\n				</div>\n			</div>\n			<div class="info-block" data-id="rest">\n				<div class="title">\n					      Реставрация\n				</div>\n				<div class="desc">\n					                                           Новые технологии лечения, с целью продления жизни деревьев.\n				</div>\n			</div>\n		</div>\n		<div class="slider-nav">\n			<a href="#" class="slider-dot"></a>\n			<!--                          -->\n			<a href="#" class="slider-dot"></a>\n			<!--                          -->\n			<a href="#" class="slider-dot"></a>\n			<!--                          -->\n			<a href="#" class="slider-dot"></a>\n		</div>\n	</div>\n</div>\n<div class="green-block">\n	<div class="wrapper">\n		                               Производим средства для защиты<br>\n		                               и лечения растений, деревьев<br>\n		                               и кустарников. Обрабатываем, защищаем<br>\n		                               и спасаем деревья с 1983 года.\n	</div>\n</div>\n<div class="info-slider">\n	<a href="#" class="slider-prev"></a><a href="#" class="slider-next"></a>\n	<div class="slider_fotorama" data-loop="true" data-width="100%" data-height="630px" data-nav="false" data-arrows="false">\n		<div class="slide">\n			<div class="wrapper">\n				<div class="koroed">\n				</div>\n				<div class="slide-text">\n					<div class="title">\n						      Короед — причина гибели леса\n					</div>\n					<div class="desc">\n						 Время вспышки распространения короедов-типографов. Спасите лес от страшного вредителя!\n					</div>\n					<p>\n						 <a href="pervaya-massovaya-obrabotka-eli-v-podmoskove" class="us-btn">Подробнее</a>\n					</p>\n				</div>\n			</div>\n		</div>\n		<div class="slide">\n			<div class="wrapper">\n				<div class="koroed">\n				</div>\n				<div class="slide-text">\n					<div class="title">\n						      Короед — причина гибели леса\n					</div>\n					<div class="desc">\n						 Время вспышки распространения короедов-типографов. Спасите лес от страшного вредителя!\n					</div>\n					<p>\n						 <a href="pervaya-massovaya-obrabotka-eli-v-podmoskove" class="us-btn">Подробнее</a>\n					</p>\n				</div>\n			</div>\n		</div>\n	</div>\n</div>', 'glavnaya', 'Главная', '', NULL, NULL, '2014-07-09 11:36:55', '2014-07-22 11:58:45'),
(2, 2, 'ru', 'О компании', '<div class="about-top wrapper">\n	<div class="about-img-pen">\n	</div>\n	<div class="about-img-tree">\n	</div>\n	<div class="about-poem">\n		                           «Ах вы, рощи мои,дерева,<br>\n		                           Не рубили бы вас на дрова...»\n	</div>\n	<div class="us-text about-text">\n		                           Компания ЛессаД занимается производством средств для защиты                         и лечения садовых растений, кустарников и деревьев с 1983 года.                         При изготовлении средств мы используем составы с пониженным содержанием ядовитых веществ, чтобы не наносить вред окружающей среде. При этом эффективность лечения и стимулирование развития растений остаются на высоком уровне.\n	</div>\n	<div class="about-block">\n		<div class="title">\n			                               Лечение, реставрация<br>\n			  и омоложение деревьев\n		</div>\n		<ul class="about-list">\n			<li>Заделка (пломбирование) дупел старых деревьев                             </li>\n			<li>Заделка (пломбирование) дупел молодых, растущих  деревьев                             </li>\n			<li>Омолаживающее опиливание деревьев                             </li>\n			<li>Оздоровление приствольных кустов                         </li>\n		</ul>\n	</div>\n	<div class="about-block abs-block">\n		<div class="title">\n			  Защита от вредителей<br>\n			  с помощью прививок\n		</div>\n		<ul class="about-list">\n			<li>«Прививки» от насекомых-вредителей                             </li>\n			<li>Борьба с борщевиком                         </li>\n		</ul>\n	</div>\n</div>', 'o-kompanii', 'О компании', '', NULL, NULL, '2014-07-09 11:37:21', '2014-07-15 09:31:27'),
(3, 3, 'ru', 'Продукция', '', 'produkciya', 'Продукция', '', NULL, NULL, '2014-07-09 11:37:34', '2014-07-15 09:29:22'),
(4, 4, 'ru', 'Опыт', '<div class="about-posts">\n	<div class="wrapper">\n		<div class="about-img-stick">\n		</div>\n		<div class="parallax">\n			<div class="par-item">\n			</div>\n			<div class="par-item">\n			</div>\n		</div>\n		<div class="us-title mar-title">\n			     Многолетний опыт работы\n		</div>\n		<div class="posts-window">\n			<ul class="post-ul">\n				<li><a href="/lechenie-vekovogo-duba-v-usadbe-griboedova" class="title">Лечение векового дуба в усадьбе Грибоедова</a>\n				<div class="desc">\n					     В усадьбе Хмелита, музее-заповеднике А. С. Грибоедова, мы вылечили вековой дуб, на котором Александр Сергеевич качался еще в ребенком. Наши специалисты Садовникова Т.П. и Войтович В.А. провели мастер-класс по лечению и заделке дупла.<br>\n				</div>\n				\n				</li>\n				<li><a href="/pervaya-massovaya-obrabotka-eli-v-podmoskove" class="title">Первая массовая обработка ели в Подмосковье</a>\n				<div class="desc">\n					     Cовместно с Мособллесом мы провели первую массовую обработку ели в подмосковье.<br>\n				</div>\n				</li>\n				<li><a href="/obrabotka-kusta-ivy-sredstvom-savoiy-1" class="title">Обработка куста ивы средством «Савой-1»</a>\n				<div class="desc">\n					     Фотоотчет о спасении куста ивы от вредителей.<br>\n				</div>\n				</li>\n			</ul>\n		</div>\n	</div>\n</div>', 'opyt', 'Опыт', '', NULL, NULL, '2014-07-09 11:37:49', '2014-07-22 11:51:10'),
(5, 5, 'ru', 'Контакты', '<div class="wrapper">\n	<div class="us-block">\n		<div class="us-title">\n			  Контакты\n		</div>\n		<div id="map-block">\n		</div>\n		<div class="contact-block">\n			<div class="us-text contact-text">\n				                                   Для получения более подробной информации об используемых нами технологиях обращайтесь к нам по следующиму адресу:\n			</div>\n			<div class="contact">\n				<h2>Адрес:</h2>\n				<div class="us-text">\n					                                       Россия, 143900,<br>\n					                                       Московская область, г. Балашиха,<br>\n					                                       Щелковское шоссе, 54-Б<br>\n				</div>\n			</div>\n			<div class="contact">\n				<h2>Телефон:</h2>\n				<div class="us-text">\n					                                       +7 (495) 502-92-90<br>\n					                                       +7 (499) 479-69-20<br>\n				</div>\n			</div>\n			<div class="contact">\n				<h2>Email:</h2>\n				<div class="us-text">\n					                                       info@lessad.ru\n				</div>\n			</div>\n		</div>\n	</div>\n</div>', 'kontakty', 'Контакты', '', NULL, NULL, '2014-07-09 11:38:06', '2014-07-15 09:31:55'),
(6, 6, 'ru', 'Мероприятия по борьбе с вредными организмами', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			    Мероприятия по борьбе с вредными организмами\n		</div>\n		                                                          В задачу сайта  входит информация о нетрадиционных  инъекционных обработках                              лесных и садовых деревьев различных пород с целью обеспечения                             их жизнедеятельности при поражении различными вредными насекомыми и инфекциями (бактериальными, грибными или вирусными). В задачу работ входит подбор наиболее эффективного способа локального введения препаратов при использовании  уменьшенных доз действующих  химических веществ, а также вспомогательных  компонентов, обеспечивающих продвижение  композиции с веществами по стволу. Благодаря герметизации отверстий  после инъекций осуществляется  циркуляция действующих веществ в замкнутой системе тканей  деревьев при отсутствии загрязнения окружающей  среды. Применяемые  обычно методы  опыливания и опрыскивания приводят к загрязнению растений и почвы  по соседству, в    особенности это усиливается при дождевых потоках, когда  ухудшается  и качество воды в ближайших водоемах.                             Против вредных  насекомых действующим веществом в применяемой композиции являются инсектициды, относящиеся к группе пиретроидов, а протии различного рода заболеваний  используются  универсальные фунгициды.                         <br>\n		                                                          Для восстановления нарушенной  целостности стволов  с образованием  дупел, морозобоин и других дефектов  осуществляется  по разработанной технологии  реставрация деревьев для продления их жизни. В  2013 году разработана  технология ускоренного проведения заделки дупел с использованием материалов, способствующих восстановлению жизнеспособности деревьев.                         <br>\n		                                                          При уплотненности почвы приствольного круга разработан способ  аэрации  почвы                             в проекции кроны, обогащение ее органическими и минеральными веществами,                             а также  повышения ее влагообеспеченности минимум на 3 года с помощью гидрогеля.                         <br>\n		                                                          Если рядом с опекаемыми деревьями растет борщевик Сосновского или он  нарушает ландшафт, то для его ликвидации разработана специальная технология  для уничтожения его  с использованием     точечной обработки,  в качестве действующего вещества                             в которой применяется гербицид. Профилактическая  обработка  хвойных деревьев против стволовых вредителей с помощью инъекций проводится  при расчете доз инсектицидов, исходя из площади боковой поверхности при различной толщине стволов, и она  не требует повторения в течение сезона. В завис имости от вредителей и степени поражения ими  хвойных деревьев инъекции осуществляются в различные их части – под кору стволов, в корневые лапы или в район тонких корневых корешков. Дозы действующих веществ, которые рекомендуются при  инъекциях, уменьшены в 3 раза                             по сравнению с требующимися дозами для обработки кроны опрыскиванием.                             При инъекциях лиственных, орехоплодных пород деревьев и кустарников сложно учесть площадь боковой поверхности из-за разветвлений кроны и поэтому  для гарантии  дополнительно делается шприцевание  почвы в районе приствольного круга с введением  действующих веществ на сорбентах.                         <br>\n		<h2>Ускоренный вариант проведения работ по заделке дупел на деревьях</h2>\n		                                                          В рекомендациях, которые    описывались  ранее по реставрации деревьев, используются различные жидкие химические препараты  и  строительные смеси, содержащие цемент, что требует   достаточно много времени для окончания процессов впитывания, испарения и отверждения. В новом варианте  пломбирования полость дупла ничем не заполняется,                             а связующая смесь затвердевает за несколько минут. Технология состоит из нескольких этапов:                         <br>\n		<ol>\n			<li>После зачистки полости дупла от трухи и мусора она опрыскивается аэрозольным антисептиком. Если дупло имеет большой размер в поперечнике или длиной около полуметра, то необходимо  провести  фумигацию или  обработку  инсектицидом также                             в аэрозольном варианте для предотвращения развития  в древесине муравьев, точильщиков и образования гнезд ос и шершней.                              </li>\n			<li>Для того, чтобы питательные соки не проникали в поверхностные слои древесины полости дупла их необходимо покрыть гидрофобизирующим  составом.                              </li>\n			<li>Во избежание скапливания воды в основание полости дупла помещается специальный сорбент с антисептиком.                              </li>\n			<li>На отверстие дупла прибивается металлическая сетка, которая крепится за 5 см                             от контура полости  дупла  и покрывается связующим составом из цемента                             и алебастра. Процесс отверждения смеси  занимает несколько минут, после чего                             на него накладывается мешковина. После прикрепления куска мешковины на нее  также наносится связующий состав.                              </li>\n			<li>Образовавшееся  покрытие   обмазывается гидроизолирующей пастой, которая предварительно декорируется под цвет здоровой части ствола дерева.                         </li>\n		</ol>\n		<h2>Таблица размеров дерева, уколов в дерево и расходов средств Савой 1/2/3</h2>\n		<table>\n		<tbody>\n		<tr>\n			<th>\n				    Диаметр дерева (см)\n			</th>\n			<th>\n				    Диаметр окружности (см)\n			</th>\n			<th>\n				    Количество мест уколов (шт.)\n			</th>\n			<th>\n				    Расход средства (мл)\n			</th>\n		</tr>\n		<tr>\n			<td>\n				    10\n			</td>\n			<td>\n				    31,4\n			</td>\n			<td>\n				    2\n			</td>\n			<td>\n				    2-3\n			</td>\n		</tr>\n		<tr>\n			<td>\n				    10\n			</td>\n			<td>\n				    31,4\n			</td>\n			<td>\n				    2\n			</td>\n			<td>\n				    2-3\n			</td>\n		</tr>\n		<tr>\n			<td>\n				    10\n			</td>\n			<td>\n				    31,4\n			</td>\n			<td>\n				    2\n			</td>\n			<td>\n				    2-3\n			</td>\n		</tr>\n		<tr>\n			<td>\n				    10\n			</td>\n			<td>\n				    31,4\n			</td>\n			<td>\n				    2\n			</td>\n			<td>\n				    2-3\n			</td>\n		</tr>\n		</tbody>\n		</table>\n	</div>\n</div>', 'meropriyatiya-po-borbe-s-vrednymi-organizmami', 'Мероприятия по борьбе с вредными организмами', '', NULL, NULL, '2014-07-15 09:28:47', '2014-07-15 09:28:47'),
(7, 7, 'ru', 'Результаты поиска', '', 'rezultaty-poiska', 'Результаты поиска', '', NULL, NULL, '2014-07-15 12:57:13', '2014-07-15 13:04:34'),
(9, 9, 'ru', 'Савой-1', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			                           Савой-1\n		</div>\n		<p>\n			                   Применяется для защиты любых деревьев от листогрызущих и сосущих вредных насекомых, стволовых вредителей ели – короеда типографа и большого черного елового усача, для лечения, реставрации деревьев и др. болезней растений. Применяется для борьбы против стенографа и хермеса.\n		</p>\n		<p>\n			       Средство «Савой-1» для профессионального применения в защите и лечении растений, является лучшим отечественным средством для защиты растений разработан и проверен ещё в СССР.\n		</p>\n		<h2>Свойства</h2>\n		<div>\n			               Средство «Савой-1» — это сложная композиция, содержащая бактерицид, безопасный ПАВ, инсектицид относящейся к не долго живущей группе пиретроидов 3 поколения. Средство «Савой-1» содержит компонент, являющийся синергистом, усиливающим его активность, а также дополнительные безопасные вещества, способствующие смачиванию и транспортированию смеси с питательным соком по тканям дерева и растения.\n		</div>\n		<div>\n			               «Савой-1» выпускается как однокомпонентное средство виде жидкости. Имеет варианты «Савой-1С» для садов и «Савой-1Т» для лесов (тайги).\n		</div>\n		<ul class="about-list">\n			<li>«Савой-1» относится к 3 классу опасности (умеренно опасное соединение).</li>\n			<li><span style="background-color: initial;">Симптомы отравления: Отравления людей не опасны. Специфических антидотов не существует. Применять симптоматическую терапию.</span></li>\n			<li><span style="background-color: initial;">100% уничтожения широкого спектра вредителей.</span></li>\n			<li><span style="background-color: initial;">Отсутствие распыления.</span></li>\n			<li><span style="background-color: initial;">Безопасно в применении. Безопасно для воды.</span><span style="background-color: initial;"> </span></li>\n		</ul>\n		<h2>Порядок использования</h2>\n		<ul class="about-list">\n			<li><span style="background-color: initial;">Подготовка раствора. </span><span style="background-color: initial;">Тщательно перемешать 5 минут. Открыть тару с составом и взять шприцом 5 мл «Савой-1», это доза для одного среднего дерева до 30 см в диаметре.</span></li>\n			<li><span style="background-color: initial;">Средство </span><span style="background-color: initial;">«Савой-1»</span><span style="background-color: initial;"> заливаются в просверленные отверстия под углом 45 градусов через кору дерева и на глубину 1,5–2,0 мм глубже коры дерева. Если впитываемость раствора маленькая, то делают несколько отверстий.</span></li>\n			<li><span style="background-color: initial;">В некоторых случаях, возможно делать уколы-инъекции в выступающие корневища.</span></li>\n			<li><span style="background-color: initial;">«Савой-1»</span><span style="background-color: initial;"> может заливаться шприцом по 1–1,5мл под кору небольшими партиями, в надрезанные и отогнутые участки по 2–3 см садовым ножом. Надрезать следует, не затронув ствол дерева и не отломив кору. Надрезы делают на расстоянии 20 см друг от друга над лапами дерева на уровне груди. После введения препарата кора возвращается на место и укрепляется.</span></li>\n			<li><span style="background-color: initial;">Для применения </span><span style="background-color: initial;">«Савой-1»</span><span style="background-color: initial;"> можно использовать специализированное оборудование – инъектор-шприц </span><span style="background-color: initial;">«Савой»,</span><span style="background-color: initial;"> специально созданный для инъекций под кору деревьев. Используется при массовой обработки большого количества деревьев. Скорость обработки 1–2 мин/дерево.</span></li>\n		</ul>\n		<div>\n			<strong>Внимание</strong>: превышение дозы 5 мл для деревьев диаметром до 20–30 см критично для их жизни. <span style="background-color: initial;">В случаях мелких кустарников и малых деревьев необходимо снижать дозу. </span><span style="background-color: initial;">В случаях большой вегетативной кроны дозу необходимо увеличить.</span>\n		</div>\n		<div>\n			              Способом инъекций целесообразно обрабатывать высокие деревья, поскольку при традиционной обработке требуется наличие подъёмника. Инъекции также эффективны против сосущих вредителей (тли, клещи, трипсы) в теплицах и в зимних садах. Если дерево имеет тонкую кору, или это крупный кустарник, то композиция наносится не в жидком виде, а в виде пасты. При этом дозировка рассчитывается согласно рекомендациям для опрыскивания листвы. Во всех случаях обработка проводится не профилактической, как у хвойников, а истребительной.\n		</div>\n		<div>\n			              После введения препарата отверстия следует запломбировать искусственной корой «Савой».\n		</div>\n		<h2>Меры безопасности при транспортировке, применение и хранении</h2>\n		<p>\n			 <strong> При работе с препаратом</strong>: Избегать попадания на кожу и в глаза. Не курить, не пить и не принимать пищу. Работать в перчатках, респираторе, защитных очках и спецодежде. Необходимо соблюдать Санитарные правила и нормативы 1.2.2584-10 «Гигиенические требования к безопасности процессов испытаний, хранения, перевозки, реализации, применения, обезвреживания и утилизации пестицидов и агрохимикатов».  <strong> После обработки</strong>: Тщательно очистить и промыть руки и оборудование. Средства индивидуальной защиты снимать в следующем порядке: не снимая с рук, вымыть перчатки 5% раствором соды и водой затем снять их.        Срок годности 2 года с даты производства.\n		</p>\n	</div>\n</div>', 'savoiy-1', 'Савой-1', '', NULL, NULL, '2014-07-21 10:59:09', '2014-07-22 07:16:06'),
(11, 11, 'ru', 'Первая массовая обработка ели в подмосковье (совместно с Мособллесом)', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			             Первая массовая обработка ели в подмосковье\n		</div>\n		<p>\n			     Cовместно с Мособллесом мы провели первую массовую обработку ели в <a href="http://maps.yandex.ru/?um=zoyI4aW8cYkal__Xfycwfk6inOgYHrXD&amp;ll=36.897184%2C55.922139&amp;spn=0.014377%2C0.005139&amp;z=17&amp;l=map" target="_blank">подмосковье</a>.\n		</p>\n		<h2>Фотоотчет</h2>\n		<p>\n			<span style="background-color: initial;">Обработка ели — стволовая прививка.</span>\n		</p>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/ClydF3urdXOgF4gj.jpg">\n		</p>\n		<p>\n			<span style="background-color: initial;"></span><span style="background-color: initial;">Отдельно стоящий лесной массив у реки.</span>\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/obKhS70WdnVmtu7s.jpg">\n		</p>\n		<p>\n			    Погибшая ель, заселенная личинками черного елового усача.\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/hiP9TF0XchRmII0T.jpg" style="opacity: 1;">\n		</p>\n		<p>\n			 Погибшая ель с отверстиями заселения черного елового усача.\n		</p>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/mW83AZurWeZfOFMi.jpg">\n		</p>\n		<p>\n			 Сухостой и зеленый сухостой ели. Деревья мертвы.\n		</p>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/JoMi4tuUMP4Id6Ah.jpg">\n		</p>\n		<p>\n			 Участок, который будет защищаться.\n		</p>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/dJyrx1B3F7qjcX7m.jpg">\n		</p>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/1Ch6WcllddZZ0N21.jpg">\n		</p>\n		<p>\n			 Результат санитарной рубки.\n		</p>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/avOpDVDtNm6PY993.jpg">\n		</p>\n	</div>\n</div>', 'pervaya-massovaya-obrabotka-eli-v-podmoskove-sovmestno-s-mosobllesom', 'Первая массовая обработка ели в подмосковье (совместно с Мособллесом)', '', NULL, NULL, '2014-07-22 09:21:39', '2014-07-22 09:46:57'),
(12, 12, 'ru', 'Лечение векового дуба в усадьбе Грибоедова', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			<p>\n				  Лечение векового дуба в усадьбе Грибоедова\n			</p>\n		</div>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/FY0bbgOUgefSA6DX.jpg" style="opacity: 1;">\n		</p>\n		<p>\n			  В усадьбе Хмелита, музее-заповеднике А. С. Грибоедова, мы вылечили вековой дуб, на котором Александр Сергеевич качался еще в ребенком. Наши специалисты <span style="background-color: initial;">Садовникова Т.П. и Войтович В.А. провели мастер-класс по лечению и заделке дупла.</span><span style="background-color: initial;"> </span>\n		</p>\n		<h2>Фотоотчет</h2>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/IReCuo5ldoSW5pei.jpg">\n		</p>\n		<p>\n			 <img src="http://test.grapheme.ru/uploads/VE39o3TekmHu4uF3.jpg" style="opacity: 1;">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/OMb8fr0a3UEkANXe.jpg" style="opacity: 1;">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/rfdwl3OFcu7MDUkI.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/9tdUoLTeZpj3RlEQ.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/xyeWGKfrtEBmkB00.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/HHzCZurF352n2F8q.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/8OT19KDTVS8Y7GlZ.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/ieTg8IpdI7OFkeIL.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/y0iQsUZP9xoIrceH.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/amBGJlJECtOeOpbi.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/nhctG6GpX1us3JpR.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/4OyeK5HIFPoRe4wM.jpg">\n		</p>\n	</div>\n</div>', 'lechenie-vekovogo-duba-v-usadbe-griboedova', 'Лечение векового дуба в усадьбе Грибоедова', '', NULL, NULL, '2014-07-22 09:46:45', '2014-07-22 10:24:20'),
(13, 13, 'ru', 'Обработка куста ивы средством «Савой-1»', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			  Обработка куста ивы средством «Савой-1»\n		</div>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/PXE3EEM257EjLwRz.jpg">\n		</p>\n		<p>\n			Ива в начале мая и такой оставалась до августа, и только в августе давала вторые листья. Всю летнюю жару были без тени! От этих насекомых:\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/8rozRpbsEHlo6b4T.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/tpRYRTZb284cdKjl.jpg">\n		</p>\n		<h2>Лечение</h2>\n		<p>\n			Сделали уколы средством Савой по 1-1,5 мл под кору, и летом ива заколосилась новыми листьями. Уколы сделаны были поздно в июне, когда все ветки были уже обглоданы.\n		</p>\n		<p>\n			<span style="background-color: initial;">Новые листья подъедали насекомые, но при этом и гибли. На эти свежие листья слетались ещё насекомые с соседних деревьев, в результате и на соседних стало мало гусениц, тли и других.</span>\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/RAVgxZZNVokOQGN6.jpg">\n		</p>\n		<p>\n			<span style="background-color: initial;"></span><span style="background-color: initial;">Привитая инъекциями «Савой-1» ива дала новые листочки. Фото сделано в августе. Полноценно распуститься ива не успела. Но ни одного насекомого на ней не было, хотя листья были подгрызены с краёв</span>.\n		</p>\n		<p>\n			На следующий год в апреле были сделаны инъекции средством «Савой-1» заблаговременно. Насекомые пытались съесть некоторые листочки. Результат отменный! Посмотрите общий результат на фото, она ранее никогда не пылила пухом, ее просто съедали!\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/mEZEUPF6O4UsbQHg.jpg">\n		</p>\n		<p>\n			<img src="http://test.grapheme.ru/uploads/EmATppMDa3Mhj6Ov.jpg">\n		</p>\n	</div>\n</div>', 'obrabotka-kusta-ivy-sredstvom-savoiy-1', 'Обработка куста ивы средством «Савой-1»', '', NULL, NULL, '2014-07-22 11:11:10', '2014-07-22 11:17:47');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_i18n_pages_table', 1),
('2014_01_01_100070_create_i18n_news_table', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_tags_table', 1),
('2014_06_19_133757_create_production_tables', 1),
('2014_07_07_135807_create_session_table', 1),
('2014_07_08_145049_create_reviews_table', 2),
('2014_07_14_124747_create_channels_tables', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'pages', 1, 0, '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(2, 'news', 0, 0, '2014-07-07 14:32:27', '2014-07-15 09:25:05'),
(3, 'galleries', 1, 0, '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(4, 'tags', 0, 0, '2014-07-07 14:32:27', '2014-07-15 09:25:09'),
(5, 'production', 1, 0, '2014-07-07 14:40:49', '2014-07-07 14:40:49'),
(6, 'reviews', 1, 0, '2014-07-09 11:39:34', '2014-07-09 11:39:34'),
(7, 'channels_menu', 1, 0, '2014-07-15 09:25:00', '2014-07-15 09:25:00');

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `name`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, '1404905995_1017.jpg', '0', '2014-07-09 11:39:55', '2014-07-09 11:39:55'),
(11, '1405934576_1607.jpg', '0', '2014-07-21 09:22:56', '2014-07-21 09:22:56'),
(12, '1405942766_1483.jpg', '-1', '2014-07-21 11:39:27', '2014-07-21 11:39:36'),
(13, '1405943816_1680.png', '-1', '2014-07-21 11:56:56', '2014-07-21 11:56:58'),
(14, '1405943837_1431.png', '-1', '2014-07-21 11:57:17', '2014-07-21 11:57:19'),
(15, '1405943855_1720.png', '-1', '2014-07-21 11:57:35', '2014-07-21 11:57:36'),
(16, '1405943867_1453.png', '-1', '2014-07-21 11:57:47', '2014-07-21 11:57:49'),
(17, '1405943880_1479.png', '-1', '2014-07-21 11:58:00', '2014-07-21 11:58:02'),
(18, '1405944215_1802.jpg', '0', '2014-07-21 12:03:35', '2014-07-21 12:03:35'),
(19, '1405944746_1234.jpg', '0', '2014-07-21 12:12:26', '2014-07-21 12:12:26'),
(20, '1405947480_1661.jpg', '-1', '2014-07-21 12:58:00', '2014-07-21 12:58:10'),
(22, '1405947832_1632.jpg', '-1', '2014-07-21 13:03:52', '2014-07-21 13:03:55'),
(23, '1405949024_1033.jpg', '-1', '2014-07-21 13:23:44', '2014-07-21 13:24:34');

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT '0',
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `short` text COLLATE utf8_unicode_ci,
  `desc` text COLLATE utf8_unicode_ci,
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `category_id`, `title`, `link`, `short`, `desc`, `image_id`, `gallery_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'Савой 1', 'http://www.conferum.ru/product/savoiy-1', '<p>\n	   Средство для защиты любых деревьев и кустарников. Применяется для борьбы с листогрызущими и листососущими насекомыми. Защищает от короеда-типографа, большого черного елового усача, стенографа и хермеса. Эффективен для лечения и реставрации деревьев.\n</p>\n<table class="product-table">\n<tbody>\n<tr>\n	<td>\n		             1 500 руб\n	</td>\n	<td>\n		             100 гр\n	</td>\n	<td>\n		             10–30 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		             3 750 руб\n	</td>\n	<td>\n		             250 гр\n	</td>\n	<td>\n		             25–65 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		             15 000 руб\n	</td>\n	<td>\n		          1 000 гр\n	</td>\n	<td>\n		             100–300 деревьев\n	</td>\n</tr>\n</tbody>\n</table>', '<div class="wrapper">\n	<div class="about-img-stick">\n	</div>\n	<div class="parallax">\n		<div class="par-item">\n		</div>\n		<div class="par-item">\n		</div>\n	</div>\n	<div class="us-block us-page">\n		<div class="us-title">\n			                                Савой-1\n		</div>\n		<p>\n			                        Применяется для защиты любых деревьев от листогрызущих и сосущих вредных насекомых, стволовых вредителей ели – короеда типографа и большого черного елового усача, для лечения, реставрации деревьев и др. болезней растений. Применяется для борьбы против стенографа и хермеса.\n		</p>\n		<p>\n			            Средство «Савой-1» для профессионального применения в защите и лечении растений, является лучшим отечественным средством для защиты растений разработан и проверен ещё в СССР.\n		</p>\n		<h2>Свойства</h2>\n		<div>\n			                    Средство «Савой-1» — это сложная композиция, содержащая бактерицид, безопасный ПАВ, инсектицид относящейся к не долго живущей группе пиретроидов 3 поколения. Средство «Савой-1» содержит компонент, являющийся синергистом, усиливающим его активность, а также дополнительные безопасные вещества, способствующие смачиванию и транспортированию смеси с питательным соком по тканям дерева и растения.\n		</div>\n		<div>\n			                    «Савой-1» выпускается как однокомпонентное средство виде жидкости. Имеет варианты «Савой-1С» для садов и «Савой-1Т» для лесов (тайги).\n		</div>\n		<ul>\n			<li>«Савой-1» относится к 3 классу опасности (умеренно опасное соединение).</li>\n			<li><span style="background-color: initial;">Симптомы отравления: Отравления людей не опасны. Специфических антидотов не существует. Применять симптоматическую терапию.</span></li>\n			<li><span style="background-color: initial;">100% уничтожения широкого спектра вредителей.</span></li>\n			<li><span style="background-color: initial;">Отсутствие распыления.</span></li>\n			<li><span style="background-color: initial;">Безопасно в применении. Безопасно для воды.</span><span style="background-color: initial;"> </span></li>\n		</ul>\n		<h2>Порядок использования</h2>\n		<ul>\n			<li><span style="background-color: initial;">Подготовка раствора. </span><span style="background-color: initial;">Тщательно перемешать 5 минут. Открыть тару с составом и взять шприцом 5 мл «Савой-1», это доза для одного среднего дерева до 30 см в диаметре.</span></li>\n			<li><span style="background-color: initial;">Средство </span><span style="background-color: initial;">«Савой-1»</span><span style="background-color: initial;"> заливаются в просверленные отверстия под углом 45 градусов через кору дерева и на глубину 1,5–2,0 мм глубже коры дерева. Если впитываемость раствора маленькая, то делают несколько отверстий.</span></li>\n			<li><span style="background-color: initial;">В некоторых случаях, возможно делать уколы-инъекции в выступающие корневища.</span></li>\n			<li><span style="background-color: initial;">«Савой-1»</span><span style="background-color: initial;"> может заливаться шприцом по 1–1,5мл под кору небольшими партиями, в надрезанные и отогнутые участки по 2–3 см садовым ножом. Надрезать следует, не затронув ствол дерева и не отломив кору. Надрезы делают на расстоянии 20 см друг от друга над лапами дерева на уровне груди. После введения препарата кора возвращается на место и укрепляется.</span></li>\n			<li><span style="background-color: initial;">Для применения </span><span style="background-color: initial;">«Савой-1»</span><span style="background-color: initial;"> можно использовать специализированное оборудование – инъектор-шприц </span><span style="background-color: initial;">«Савой»,</span><span style="background-color: initial;"> специально созданный для инъекций под кору деревьев. Используется при массовой обработки большого количества деревьев. Скорость обработки 1–2 мин/дерево.</span></li>\n		</ul>\n		<div>\n			 <strong>Внимание</strong>: превышение дозы 5 мл для деревьев диаметром до 20–30 см критично для их жизни. <span style="background-color: initial;">В случаях мелких кустарников и малых деревьев необходимо снижать дозу. </span><span style="background-color: initial;">В случаях большой вегетативной кроны дозу необходимо увеличить.</span>\n		</div>\n		<div>\n			                   Способом инъекций целесообразно обрабатывать высокие деревья, поскольку при традиционной обработке требуется наличие подъёмника. Инъекции также эффективны против сосущих вредителей (тли, клещи, трипсы) в теплицах и в зимних садах. Если дерево имеет тонкую кору, или это крупный кустарник, то композиция наносится не в жидком виде, а в виде пасты. При этом дозировка рассчитывается согласно рекомендациям для опрыскивания листвы. Во всех случаях обработка проводится не профилактической, как у хвойников, а истребительной.\n		</div>\n		<div>\n			                   После введения препарата отверстия следует запломбировать искусственной корой «Савой».\n		</div>\n		<h2>Меры безопасности при транспортировке, применение и хранении</h2>\n		<p>\n			<strong> При работе с препаратом</strong>: Избегать попадания на кожу и в глаза. Не курить, не пить и не принимать пищу. Работать в перчатках, респираторе, защитных очках и спецодежде. Необходимо соблюдать Санитарные правила и нормативы 1.2.2584-10 «Гигиенические требования к безопасности процессов испытаний, хранения, перевозки, реализации, применения, обезвреживания и утилизации пестицидов и агрохимикатов».  <strong> После обработки</strong>: Тщательно очистить и промыть руки и оборудование. Средства индивидуальной защиты снимать в следующем порядке: не снимая с рук, вымыть перчатки 5% раствором соды и водой затем снять их.        Срок годности 2 года с даты производства.\n		</p>\n	</div>\n</div>', 13, 0, '2014-07-16 08:23:07', '2014-07-22 10:29:33'),
(2, 1, 'Савой 2', 'http://www.conferum.ru/product/sredstva-dlya-zashity-derevev-savoiy-2', '<p>\n	  Средство для инъекционной обработки лесных и плодовых деревьев, а также защиты деревьев и кустарников. Применяется для инъекций от листогрызущих и листососущих насекомых, стволовых вредителей. Защищает от короеда-типографа, большого черного елового усача, стенографа и хермеса. Эффективен для лечения и реставрации деревьев.\n</p>\n<table class="product-table">\n<tbody>\n<tr>\n	<td>\n		         2 640 руб\n	</td>\n	<td>\n		           160 гр\n	</td>\n	<td>\n		           15–30 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		           7 040 руб\n	</td>\n	<td>\n		        480 гр\n	</td>\n	<td>\n		           40–130 деревьев\n	</td>\n</tr>\n<tr>\n	<td>\n		        17 600 руб\n	</td>\n	<td>\n		           1 600 гр\n	</td>\n	<td>\n		           200 деревьев\n	</td>\n</tr>\n</tbody>\n</table>', '', 14, 0, '2014-07-21 08:54:43', '2014-07-22 10:33:18'),
(3, 1, 'Савой П-1', 'http://www.conferum.ru/product/savoiy-p1', '<p>\n	 Комплект подкормки на 10 деревьев с пролонгацией защиты от короедов и других насекомых на 1 год.\n</p>\n<p>\n	   Состав  сохраняет влагу для дерева, подпитывает удобрениями дерево и медленно  отдаёт Савой 1/2/3 дереву, который не даёт распространиться насекомым в  корнях, стволе и вегетативной части дерева.\n</p>', '', 15, 0, '2014-07-21 08:59:30', '2014-07-22 10:34:04'),
(4, 1, 'Савой Б', 'http://www.conferum.ru/product/savoiy-b', '<p>\n	 Комплект для удаления борщевика Сосновского на площади 30–100 м².\n</p>\n<p>\n	   Савой Б — это высокая эффективность технологии; низкий расход гербицида с точной дозировкой; безопасность рядом находящихся деревьев и других растений.\n</p>', '', 16, 0, '2014-07-21 09:04:12', '2014-07-22 10:33:44'),
(5, 1, 'Савой П-3', 'http://www.conferum.ru/product/savoiyp3', '<p>\n	 Комплект подкормки на 10 деревьев с удержанием влаги на 3 года.\n</p>\n<p>\n	   Состав сохраняет влагу для дерева, подпитывает удобрениями дерево и медленно отдаёт их дереву в течении 3 лет. Применяется для поддержания растений с засушливый период и после проведения инъекций в ствол.\n</p>', '', 17, 0, '2014-07-21 09:06:30', '2014-07-22 10:34:19');

-- --------------------------------------------------------

--
-- Структура таблицы `products_category`
--

DROP TABLE IF EXISTS `products_category`;
CREATE TABLE IF NOT EXISTS `products_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `products_category`
--

INSERT INTO `products_category` (`id`, `title`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Основная категория', NULL, '2014-07-16 08:22:22', '2014-07-16 08:22:22');

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rel_mod_gallery_module_index` (`module`),
  KEY `unit_id` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `language` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `image_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_publication_index` (`publication`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `language`, `name`, `position`, `content`, `slug`, `template`, `publication`, `image_id`, `gallery_id`, `created_at`, `updated_at`, `published_at`) VALUES
(2, NULL, 'Грицай А.В.', 'ТСЖ «Зеленый городок», п. Андреевка', '<p>\n	  Летом 2012 года я нашла Специалиста по борьбе с типографом — Садовникову Татьяну Петровну. Татьяна Петровна применила свою технологию по профилактике заражения типографом инсектицидом системного действия — препаратом «Савой» и оздоровления деревьев. Результат — лес на моем участке сохранен.\n</p>', 'reviews-2', 'default', 1, 11, 0, '2014-07-09 11:45:46', '2014-07-21 09:22:58', '2014-07-09');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('0359e0207ba23cf27a4f6468d4cbaf08ae764db1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibU9Db3pWYWFtcXpWN2J4ek1SWjJ0bUpINkJqUFlHMW1WSzJiTkZVbSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDM4NDM7czoxOiJjIjtpOjE0MDYxMDM4NDM7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406103846),
('081199747e400da311e65443b68c40adf989881d', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYjkwakhwZWt0R21QUFFjTXJmMUFNWVZ6SVkzdGJ4elZ4NlNyVUQ4UyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDAyMzA7czoxOiJjIjtpOjE0MDYxMDAyMzA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406100230),
('28374f6bba41409f4c3a1d9cfd6f71d22e55207f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjhnS3E5QmVxZ2M5eERqMmFWVUFLTDIzOUVhd2dNRjRtOUUxT2k5eiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDM0NDA7czoxOiJjIjtpOjE0MDYxMDM0NDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406103442),
('6cdec0f8221f7d95095c9d2d6337646f4af2fb4b', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibElpU051cm1xblVmYzlnZFNFR2d6Rk5mZHF4Sk9qNFA4THpWeE85eCI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDEzMTk7czoxOiJjIjtpOjE0MDYxMDEzMTk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406101322),
('72bd0c8259980250ccd897d3bc1f47309c4054b7', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoielMzT21jemtnQUxjSG9nYzRDYkZmRXFEMHZJQWQ1RDJ0eEVqS0Y3bSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDM3MDY7czoxOiJjIjtpOjE0MDYxMDM3MDY7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406103708),
('7fa2afbccfd9d1c4ee956ff2191ea54455344964', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHRRWUp5OHhQdWF3OUwxNFBXdUJ3eUNYUWJpeXo5THRURlJHVnhXQSI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwNjEwMjQyNTtzOjE6ImMiO2k6MTQwNjEwMjQyNDtzOjE6ImwiO3M6MToiMCI7fX0=', 1406102425),
('81c154cc699346409ce152e2bcb79992374494d4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNW5NZ2pSeENKcEpuZDNsY0ZTam5NTVJwSUVDeEVkM1R2RThQUnRETCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwNjEwMjE1MjtzOjE6ImMiO2k6MTQwNjEwMDg0MjtzOjE6ImwiO3M6MToiMCI7fX0=', 1406102152),
('87b419891e611f8bff0c40b332b1d7c1418ecf68', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibm01WUhwemZjWVJYUkh6Z044dEExZFpaY21aZVFMUTluZWN4dEZJViI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6Il9zZjJfbWV0YSI7YTozOntzOjE6InUiO2k6MTQwNjEwMjYzMjtzOjE6ImMiO2k6MTQwNjEwMjYyNjtzOjE6ImwiO3M6MToiMCI7fX0=', 1406102632),
('913e42ef08b6396bad0c940231180df9a9545c4a', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNmJUVUt5SkFCTWx1emFTVFJCdkdiM3U4eHBpRm5wSmNzMWxnM0pZaiI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDE2ODI7czoxOiJjIjtpOjE0MDYxMDE2ODI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406101682),
('96aeeb59dcd350d65895d9920180e85783ff82ab', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidEVuT3A2QXhoQkx2Q0lMZVdTa2dOT2dHWWF6WDFEclZBUWRPM3RhYSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDQ2ODQ7czoxOiJjIjtpOjE0MDYxMDQ2ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406104687),
('a66704ccb641b21656dfb64c2dda37e8a73d7243', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoic3VVdFBleWs1RUpzakdDZjVuWGZaWGJlUWZua28yaUp0UzZaMjZkNSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDM0MjI7czoxOiJjIjtpOjE0MDYxMDM0MjI7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406103425),
('b6331c9203a1b2ccb046f0b5fee13f1198b6e077', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTlJQUld3R3lMWGppT0w0QU9Bb2w3WG1mdmpUanYxZWxUNWgyM2oxSyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDIzNDU7czoxOiJjIjtpOjE0MDYxMDIzNDU7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406102345),
('bb3df0db00c9ae90a94999c3ddf8681816a349a4', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoieWI0VG9sWDF4NFdUVmxpU05hYkFjY3ZuUFVtQ3ZvMnMyZGdRckNWcSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDE2ODQ7czoxOiJjIjtpOjE0MDYxMDE2ODQ7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406101684),
('d2be746f2c4cdf003bcc7c1497e78c229a7aa20e', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYVJzSWJJTG9LcVNKbDdyYlVYU2h3NWlJVklwUEl6OThUUEVmb3BCMSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDIxMDA7czoxOiJjIjtpOjE0MDYxMDIxMDA7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406102103),
('e92358dee1e2d6091e4afdefaa41fad215d4f8cb', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTG14UHNEOGpqM2UxcVpyN3ppR0VuQlBrNE93a2k2eDU3ZFR4VDRLdyI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDEzMDk7czoxOiJjIjtpOjE0MDYxMDEzMDk7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406101312),
('f1a8e6fa08a43757dc1a86a41e7038ae568b4f0f', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlozQmNuMjVSdU41YnY3ODQ1TmF2WUNEZDJwd1NVMVZDbFFVbFA4OSI7czo5OiJfc2YyX21ldGEiO2E6Mzp7czoxOiJ1IjtpOjE0MDYxMDI2NDc7czoxOiJjIjtpOjE0MDYxMDI2NDc7czoxOiJsIjtzOjE6IjAiO31zOjU6ImZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1406102649);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-07-07 14:32:27', '2014-07-07 14:32:27');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `tag` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_module_unit_id_tag_unique` (`module`,`unit_id`,`tag`),
  KEY `tags_module_index` (`module`),
  KEY `tags_module_unit_id_index` (`module`,`unit_id`),
  KEY `tags_tag_index` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@lessad.ru', 1, '$2y$10$h4Il0sgQtQVK5kW0zdLraOG5hYHNyHbZRqXvIXkgddLsJZ7jkpgwC', '', '', '', 0, 'PscKmsDJCAzBeQcC5BYaMEWdQ5kqBchszPvOM0FUT5vqRVZBmneAxVnTSy6C', '2014-07-07 14:32:27', '2014-07-07 14:40:39'),
(2, 2, 'Пользователь', '', 'user@lessad.ru', 1, '$2y$10$Li7WTdg7N6YVtD2S1rQSmeHDLm3AKBnwvgPz5Ymh8jZedSYGs1vwa', '', '', '', 0, NULL, '2014-07-07 14:32:27', '2014-07-07 14:32:27'),
(3, 3, 'Модератор', '', 'moder@lessad.ru', 1, '$2y$10$T6ncASnknrjq.AjcBzSERuH96ZPhcjYJgnJyUjd8nQ08buWlUXxli', '', '', '', 0, NULL, '2014-07-07 14:32:27', '2014-07-07 14:32:27');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
